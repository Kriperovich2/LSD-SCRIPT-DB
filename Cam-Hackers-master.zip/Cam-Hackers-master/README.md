# Cam-Hackers

Hack Cameras

<h3> Run Command: </h3>

* apt-get install python3

* apt-get install git

* git clone https://github.com/AngelSecurityTeam/Cam-Hackers

* cd Cam-Hackers

* pip install -r requirements.txt

* python3 cam-hackers.py 

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/cap01new.jpg">

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/cap02new.jpg">

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/camfoto.png">

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/camfoto2.png">

<h3> Paypal donations: </h3>

* https://www.paypal.com/paypalme/AngelSecTeam
