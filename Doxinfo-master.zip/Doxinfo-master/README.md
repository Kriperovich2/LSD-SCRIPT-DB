# Doxinfo
```
Doxing o doxeo o doxxing es la práctica en Internet de investigación y publicación de
información privada o identificante sobre un individuo o una organización. wikipedia
Doxing es el proceso de obtención de información acerca de una persona a través de
fuentes de internet, utilizando el ingenio y habilidades de búsqueda.
La palabra deriva de "document" en inglés y ing, que sería un gerundio 
en esa lengua : documentando o algo por el estilo pero queda mejor doxing
```
Doxinfo
Es un programa creado para para doxear a un individuo o una organización .
Doxinfo tiene una variedad de opciones de buscadores web para obtener datos de nuestra victimas.
- MAS INFORMACIÓN https://lpericena.blogspot.com/2019/02/doxing.html

## Comenzando 
![](https://2.bp.blogspot.com/-3JyjMAG7EJU/XHfM90oksNI/AAAAAAAANyc/KZzjUbeO6mY88yc9F5G5p9Wm-QyNai_EACLcBGAs/s1600/Screenshot_11.png)
### Pre-requisitos 
![](https://1.bp.blogspot.com/-hUVUYxzVEpk/XHfkFt92LNI/AAAAAAAAN0I/krQXsqw-DmcTvM0eHAYuV1drsIg21uxAQCLcBGAs/s1600/Screenshot_22.png)

_Que cosas necesitas para instalar el software y como instalarlas_

```
 - windows 7/10
 - USB 
```


### Donación paypal
https://www.paypal.com/paypalme/lpericena

## Deployment 
- LICENSE
- Permisos
* Uso comercial
* DistribuciÃ³n
* ModificaciÃ³n
* Uso de patentes
* Uso privado
- Condiciones	Limitaciones
*  Revelar la fuente
*  Aviso de licencia y copyright
*  Misma licencia
*  Cambios de estado
*  Responsabilidad
*  GarantÃ­a

## Construido con * [Notepad++](https://notepad-plus-plus.org/download/) - Editor de texto (IDE)
_Menciona a todos aquellos que ayudaron a levantar el proyecto desde sus inicios_

* **LuishiÃ±o Pericena Choque ** - *Desarrollo del software* - [Pericena](https://github.com/Pericena)


## Licencia

Este proyecto estÃ¡ bajo la Licencia (Licencia pÃºblica general de GNU) - mira el archivo [LICENSE.md](LICENSE.md) para detalles

## Expresiones de Gratitud 
* Bueno espero que le sea de utilidad cualquier consulta pueden dirigirse a mis redes sociales ðŸ“¢
Sigueme en las redes Sociales:
- 🌎Blogger          https://lpericena.blogspot.com/
- 💡 Github            https://github.com/Pericena
- 🐤 twitter             https://twitter.com/LPericena
- 👦 linkedin         https://www.linkedin.com/in/lpericena/
* Gracias  ðŸ¤“.

---
âŒ¨ï¸ Por [Pericena](https://github.com/Pericena)
