import os

COLOR_CODE = {
        "BLUE": "\033[34m",
        "RESET": "\033[0m",
    }
os.system("cls")
print(f'''{COLOR_CODE["BLUE"]} 
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                  
                                                                                            
                          ''')                                                                                               
print('''
основные боты для докса

@clerkinfobot
@UniversalSearchRobot
@UsersSearchBot
@getcontact_real_bot
@Quickosintfast_bot
@telesint_bot
@kolibri_osint_bot
@UsersSearchBot
@usinfobot
@Doufucbot
@Douccuiccbot
@detectiva_bot
@PasswordSearchBot
@UniversalSearchBot
@StealDetectorBOT
@last4mailbot
@info_baza_bot
@get_caller_bot
@dosie_Bot
@eyeofbeholder_bot
@clerkinfobot
@TeleSINT_Bot
@fuckeddb
@freedomf0x
@usinfobot
https://saverudata.online/
https://r23.fssp.gov.ru/iss/ip
https://legalacts.ru/
https://www.nalog.gov.ru/
@kolibri_osint_bot
@Qsta_bot
@clerkinfobot
@clerkinfobot
@get_caller_bot
@Getphonetestbot
http://avinfo.guru
http://getcontact.com
http://mirror.bullshit.agency
http://numberway.com
http://mirror.bullshit.agency
http://mysmsbox.ru
http://phoneInfoga.crvx.fr
http://spravnik.com
http://teatmik.ee
http://truecaller.com


https://saverudata.online/ - Пробив по номеру, фамилии, почты может найти адрес/имя/фамилию и прочее. Так-же проверяет на базу клиентов ВТБ.
https://r23.fssp.gov.ru/iss/ip (включая под-ресурсы данного гос. ресурса)
https://legalacts.ru/ (включая под-ресурсы данного гос. ресурса)
http://www.consultant.ru/ (включая под-ресурсы данного гос. ресурса)
https://docs.cntd.ru/ (включая под-ресурсы данного гос. ресурса)
https://egrul.nalog.ru/index.html (включая под-ресурсы данного гос. ресурса)
https://nalog.ru/ (включая под-ресурсы данного гос. ресурса)
https://www.nalog.gov.ru/ (включая под-ресурсы данного гос. ресурса)
https://www.tinkoff.ru/ (включая под-ресурсы данного ресурса)
https://zachestnyibiznes.ru/ (включая под-ресурсы данного гос. ресурса)
@usersbox_bot - Хороший бот, аналогичен сайту выше, но баз там больше, и найти информации так-же можно больше. (Можно получить бесплатный премиум через меня, если надо скажи. А так там пробник на 7 дней дают)
@maigret_osint_bot - Пробив по никнейму
@kolibri_osint_bot - Идеальный бот, аналог ГБ. Бесплатно раздают на время бета теста (3 месяца вроде).
@glazIX_bot - Стандартный глазик, зеркало от пидорасов извини, своё лень было делать.
@Qsta_bot - Хороший бот, правда платный. Но дают пару запросов, я лично чекаю сообщения со страницы вк в нём в группах и т.д. для компромата, охуенный короче бот
@getcontact_real_bot - Бот для пробива по GetContact (5 запросов в день :( )
@ibhldr_bot - Пробив по чатам ТГ
├ @clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
├ @dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки
├ @find_caller_bot — найдет ФИО владельца номера телефона
├ @get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail
├ @get_kolesa_bot — найдет объявления на колеса.кз
├ @getbank_bot — дает номер карты и полное ФИО клиента банка
├ @GetFb_bot — бот находит Facebook
├ @Getphonetestbot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
├ @info_baza_bot — поиск в базе данных
├ @mailsearchbot — найдет часть пароля
├ @MyGenisBot — найдет имя и фамилию владельца номера
├ @phone_avito_bot — найдет аккаунт на Авито
├ @SafeCallsBot — бесплатные анонимные звонки на любой номер телефона с подменой Caller ID
Ресурсы для пробива
├ lampyre.io — программа выполняет поиск аккаунтов, паролей и многих других данных
├ avinfo.guru — проверка телефона владельца авто, иногда нужен VPN
├ fa-fa.kz — найдет ФИО, проверка наличия задолженностей, ИП, и ограничения на выезд
├ getcontact.com — найдет информацию о том как записан номер в контактах
├ globfone.com — бесплатные анонимные звонки на любой номер телефона
├ mirror.bullshit.agency — поиск объявлений по номеру телефона
├ mysmsbox.ru — определяет чей номер, поиск в Instagram, VK, OK, FB, Twitter, поиск объявлений на Авито, Юла, Из рук в руки, а так же найдет аккаунты в мессенджерах
├ nuga.app — найдет Instagram аккаунт, авторизация через Google аккаунт и всего 1 попытка
├ numberway.com — найдет телефонный справочник
├ personlookup.com.au — найдет имя и адрес
├ phoneInfoga.crvx.fr — определят тип номера, дает дорки для номера, определяет город
├ spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес
├ spravochnik109.link — поиск по городскому номеру телефона, найдет ФИО и адрес
├ teatmik.ee — поиск в базе организаций, ищет номер в контактах
└ truecaller.com — телефонная книга, найдет имя и оператора телефона

Пробив через Восстановление доступа
├ ICQ — icq.com/password/ru
├ Yahoo — login.yahoo.com/?display=login
├ Steam — help.steampowered.com/ru/wizard/HelpWithLoginInfo
├ Twitter — twitter.com/account/begin_password_reset
├ VK.com — vk.com/restore
├ Facebook — facebook.com/login/identify?ctx=recover
├ Microsoft — account.live.com/acsr
└ Instagram — instagram.com/accounts/password/reset


"ПРОБИВ ПАСПОРТА"
https://www.reestr-zalogov.ru/search/index - Пробив по ФИО, может выдать паспорт если есть кредит с залогом. Так-же можно пробить через VIN.


NNB - @The_NoNameBot (дает полезную инфу) 

https://eyeofgod.space/ (Актуальный глаз бога искать здесь, ибо его вечно банят) 

@EmailPhoneOSINT_bot - Получаем ФИ, почту, регион 

@phone_avito_bot - проверяем авито акич

@getcontact_real_bot - работу гет контакта, знаете

@usinfobot - получаем тг айди 

@TgAnalyst_bot - если акич попал в бд телеграмма, выдаст айпи, номер, девайс

@UniversalSearchBot - по мануалу который даст бот после пробива по номеру, узнаете вк аву

LBSG.net, Collection 1, StockX.com, 8Tracks.com, Wishbone.io, DailyQuiz.me, Zynga.com, Wattpad.com

databases.today — архив баз банков, сайтов, приложений

@basetelega — утечки, компании, парсинг открытых источников

ebaza.pro (r) — есть email, телефонные номера, физ. лица, предприятия, базы доменов и другие

hub.opengovdata.ru — Российские базы статистики, росстата, архивы сайтов, финансы, индикаторы, федеральные органы власти, суды и т.д

@freedomf0x — утечки сайтов, приложений, гос. структур

@leaks_db — агрегатор публичных утечек

@BreachedData — утечки сайтов, приложений, соц. сетей, форумов и т.д.

@opendataleaks — дампы сайтов школ, судов, институтов, форумов по всему миру

@fuckeddb — дампы сайтов, приложений, социальных сетей, школ, судов, институтов, государственных ресурсов, форумов по всему миру

@gzdata — китайские сайты и приложения 

AVinfoBot (r) – делает отчет где есть данные из социальных сетей, недвижимости, автомобилей, объявлений и телефонных книжек. Нужно пригласить другой аккаунт для отчета

getcontact.com (r) — выдает информацию о том как записан номер в контактах

truecaller.com (r) — телефонная книга, ищет имя и оператора телефона

avinfo.guru (r) — проверка телефона владельца авто, иногда нужен VPN

spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес

m.ok.ru — показывает часть номера телефона, email, фамилии и полностью город с датой регистрации, используй во вкладке инкогнито

smartsearchbot.com — бот находит ФИО, email, объявления, бесплатный поиск не доступен для новых пользователей

list-org.com — найдет организацию в РФ

odyssey-search.info (r) — сыщит ФИО, объявления Avito, автомобили, документы, места работы, контакты, а при регистрации можно указать любую российскую организацию

find-org.com — найдет компанию в РФ

 

Пробив по ID/Юзеру телеги

Telegago — найдет упоминание аккаунта в каналах, группах, включая приватные, а так же в Telegraph статьях

lyzem.com — найдет упоминание аккаунта в группах и каналах

cipher387.github.io — покажет архивированную страницу, даст 20+ прямых ссылок на сайты веб архивы, поиск по ссылке на аккаунт

tgstat.com — поиск по публичным сообщениям в каналах, найдет упоминание аккаунта

@SangMataInfo_bot — история изменения имени аккаунта

@TeleSINT_Bot — найдет группы в которых состоит пользователь

@creationdatebot — примерная дата создания аккаунта, бот принимает username, для поиска по ID можно переслать сообщение от искомого пользователя

@MySeekerBot — поисковик по иранским каналам

TelegramOnlineSpy (t) — лог онлайн активности аккаунта, скажет когда был в сети

Exgram — найдет упоминание аккаунта, это поисковая система на основе Яндекса, поиск по 17 сайтам-агрегаторам, находит в Telegraph статьях, контактах, приватных и публичных каналах с группами

Commentgram — найдет упоминание аккаунта, поиск в комментариях к постам в Telegram, работает через Google

Commentdex — найдет упоминание аккаунта, поиск в комментариях к постам в Telegram, работает через Яндекс

глазбога.рф — найдет часть номера телефона, историю изменения ссылки аккаунта

@clerkinfobot — дает номер телефона

@usersbox_bot — по нику найдет номер телефона, бесплатный доступ 14 дней после первого запуска бота

@TuriBot — выдает по ID имя пользователя аккаунта Telegram, отправь боту команду /resolve + ID

@eyeofbeholder_bot — даёт интересы аккаунта, а платно выдаст историю изменения имени, номер телефона, группы и ссылки которые публиковал пользователь

 
 Quick_OSINT_bot — найдет оператора, email, как владелец записан в контактах, базах данных и досках объявлений, аккаунты в соц. сетях и мессенджерах, в каких чатах состоит, документы, адреса и многое другое

 @clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах

 @dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки

 @find_caller_bot — найдет ФИО владельца номера телефона

 @get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail

└ @usersbox_bot — бот найдет аккаунты в ВК у которых в поле номера телефона указан искомый номер

└ @EyeGodsBot Платный. Поиск по ФИО, фото, по номеру авто, ВК, ОК, по телефону, по мылу, по телеге, по адресу и прочая прочая. Не реклама, делюсь тем чем пользуюсь сам.

└ @info_baza_bot
 

Поиск через URLh

ttps://my-medon.aviasales.ru/list?key=tg:123456789 — найдет подписки на авиабилеты, замените 123456789 на ID аккаунтаh

ttps://etlgr.me/conversations/123456789/subscription — найдет сохраненное имя аккаунта и статус подписки на @etlgr_bot, можно подставить к ID @etlgr.com и получить Email адрес, замени 123456789 на ID аккаунта

https://intelx.io/?s=https/t.me/USERNAME — найдет упоминание на сайтах и в слитых базах, замените USERNAME на имя пользователя


Поиск по почте:

1. haveibeenpwned.com — проверка почты в слитых базах

2. emailrep.io — найдет на каких сайтах был зарегистрирован аккаунт использующий определенную почту

3. dehashed.com (r) — проверка почты в слитых базах

4. intelx.io — многофункциональный поисковик, поиск осуществляется еще и по даркнету

5. @info_baza_bot — покажет из какой базы слита почта, 2 бесплатных скана

6. leakedsource.ru — покажет в каких базах слита почта

7. mostwantedhf.info — найдет аккаунт skype

8. email2phonenumber (t) — автоматически собирает данные со страниц восстановления аккаунта, и находит номер телефона

9. spiderfoot.net (r) — автоматический поиск с использованием огромного количества методов, можно использовать в облаке если пройти регистрацию

10. @last4mailbot — бот найдет последние 4 цифры номера телефона клиента Сбербанка

11. searchmy.bio — найдет учетную запись Instagram с электронной почтой в описании

12. AVinfoBot (r) — найдет аккаунт в ВК

13. account.lampyre.io (t, r) — программа выполняет поиск по аккаунтам в соц. сетях и мессенджерам и другим источникам

14. ГлазБога.com (r) — найдет фото из аккаунтов пользователя 

15. @StealDetectorBOT — поисковик по базам утечек, найдет частть пароля и источник утечек

16. cyberbackgroundchecks.com — найдет все данные гражданина США, вход на сайт разрешен только с IP адреса США

17. holehe (t) — инструмент проверяет аккаунты каких сайтов зарегистрированы на искомый email адрес, поиск по 30 источникам

18. tools.epieos.com — найдет Google ID, даст ссылки на профиль в Google карты, альбомы и календарь, найдет к каким сайтам привязана почта, профиль LinkedIn

19. @UniversalSearchBot — найдет профили на Яндекс, в сервисах Google, утекшие пароли, социальные сети, адрес регистрации, номер телефона, био, Gmail адрес и прочее

20. grep.app — поиск в репозиториях GitHub

21. @PasswordSearchBot — выдает пароли

22. Checker

@PhoneLeaks_bot - найдет в каких базах слит номер

@infobazaa_bot - найдет в слитых базах фио, адрес.



Некоторые полезные инструменты доксинга

www.whois.net

www.pipl.com

www.tineye.com

www.geobytes.com/iplocator.html

www.whitepages.com

www.118.com

www.knowem.com

http://www.spokeo.com/username-search

http://www.zabasearch.com/advanced.php

http://www.ip-address.org/lookup/ip-locator.php

skypegrab.net

http://www.proxyornot.com

https://ssndob.so

whoisology.com

indexeus.com

netcraft.com

shodan.com

intelx.io

http://www.checkusernames.com/

www.myspace.com

www.bebo.com

facebook.com/

instagram.com/

allinurl: //google.com/

www.wink.com

www.123people.com

www.zabasearch.com

http://ip-score.com/checkip

http://iknowwhatyoudownload.com/ru/peer/

http://htmlweb.ru

http://getipintel.net

🌎Поиск пастебина 🌎

🍎Политики🍎

🔘 Инструменты анализа URL 🔘

https://www.virustotal.com/gui/

https://www.urlvoid.com/

https://urlscan.io/

https://exchange.xforce.ibmcloud.com/

https://zulu.zscaler.com/

https://umbrella.cisco.com/

https://www.hybrid-analysis.com/

🔘 Инструменты анализа IP: 🔘

https://exchange.xforce.ibmcloud.com/

https://www.ipvoid.com/

https://umbrella.cisco.com/

🔘 Дополнительную информацию об IP и URL (дата создания, местоположение, организация) можно найти на 🔘

http://cqcounter.com/whois/

http://domainwhitepages.com/

http://whois.domaintools.com/

Доксинг:

1: Имя пользователя (псевдоним)

http://namechk.com/

http://knowem.com/

http://www.namecheckr.com/

http://checkusernames.com/

http://usersherlock.com/

https://www.usersearch.org/

⚡️ DOX ANY GMAIL [ИМЯ, ЖИВОЕ МЕСТОПОЛОЖЕНИЕ, ФОТОГРАФИИ, УСТРОЙСТВА, КАЛЕНДАРЬ] (ИСТОЧНИК) ⚡️

Хочу начать с того, что этот инструмент был сделан не мной.

Этот инструмент позволяет получить следующую информацию об учетной записи Gmail:

Имя владельца

Последний раз профиль редактировался

Google ID

Если это аккаунт Hangouts Bot

Активированные сервисы Google (YouTube, Фото, Карты, News360, Hangouts и т. Д.)

Возможный канал на YouTube

Возможные другие имена пользователей

Общедоступные фотографии

Модели телефонов

Прошивки телефонов

Установленное ПО

Обзоры Google Maps

Возможное физическое местонахождение

События из Google Календаря

https://github.com/mxrch/GHunt

Скачать:

https://sql.gg/upload/e4b6aa3c-d20c-493d-ad77-3d6d51381ee6

Социальная информация

1. haveibeenpwned.com - проверка просочившихся баз данных

2. emailrep.io - найти сайты, на которых был зарегистрирован аккаунт по электронной почте

3. dehashed.com - проверка почты в просочившихся базах данных

4. @Smart_SearchBot - найдите полное имя, DoB, адрес и номер телефона

5. pwndb2am4tzkvold.onion - поиск в pwndb, также поиск по паролю

6. intelx.io - многофункциональная поисковая система, поиск ведется также и в даркнете

7. @mailsearchbot - поиск по базе, выдает пароль частично

8. @shi_ver_bot - взломанные пароли

9. @info_baza_bot - показать с какой базы просочилась почта, 2 бесплатных сканирования

10. leakedsource.ru - покажите, из какой базы просочилась почта

11. mostwantedhf.info - найти аккаунт в скайпе

12. email2phonenumber (t) - автоматически собирает данные со страниц восстановления аккаунта и находит номер телефона.

13. spiderfoot.net (r) - автоматический поиск с использованием огромного количества методов, инструмент доступен в облаке с регистрацией

14. reversegenie.com - поиск местоположения, первой буквы имени и телефонных номеров

15. searchmy.bio - найти инстаграм-аккаунт с адресом электронной почты в описании

17. leakprobe.net - найдет ник и источник утечки базы данных.

18.) Получите информацию fb по электронной почте

Создать страницу в фейсбуке

Перейти на страницу диспетчера ролей

(https: //www.facebook.com/ (your-page-id) / settings /? tab = admin_roles или, например,

Введите адрес электронной почты человека, которого вы пытаетесь доказать

Имя и фамилия целей будут показаны под полем, затем просто найдите их на facebook и продолжайте свое путешествие в доксинг.

Архивы

https://archive.org/index.php

https://www.archive-it.org/

http://aad.archives.gov/aad/series-list.jsp?cat=GS29

Социальные сети

http://www.yasni.com/

http://socialmention.com/

http://www.whostalkin.com/

http://www.linkedin.com/

http://www.formspring.me/

http://foursquare.com/

https://about.me/

https://profiles.google.com/

http://blogger.com

https://twitter.com/

http://www.facebook.com/

https://deviantart.com

http://xanga.com/

http://tumblr.com/

http://myspace.com/

http://www.photobucket.com/

http://www.quora.com/

http://www.stumbleupon.com/

http://www.reddit.com

http://www.digg.com

http://www.plixi.com

http://pulse.yahoo.com/

http://www.flickr.com/

Номера телефонов

http://www.freecellphonedirectorylookup.com

http://www.numberway.com/

http://www.fonefinder.net

http://www.whitepages.com/reverse-lookup

http://www.anywho.com/reverse-lookup

http://www.yellowpages.com/reversephonelookup

http://www.spydialer.com/

http://www.intelius.com/reverse-phone-lookup.html

truecallerapp.com

IP-адреса

http://www.infosniper.net/

http://ip-lookup.net/

https://www.whatismyip.com/ip-whois-lookup/

http://whatstheirip.com

http://getthierip.com

Skype Resolvers

http://skypegrab.net/resolver.php

http://www.skresolver.com/index.php

http://resolvethem.com/

https://www.hanzresolver.com/skype2

https://skype-resolver.org/

http://mostwantedhf.info/

http://orcahub.com/skyperesolver.php

https://booter.xyz/skype-resolver/

http://cstress.net/skype-resolver/

http://iskyperesolve.com/

https://ddosclub.com/skype-resolver/index.php

Поиск по базе данных

http://skidbase.io/

haveibeenpwned.com

Leakedsource.com

WHOIS / Веб-сайт

https://www.whois.net/

http://whois.icann.org/en

https://who.is/

http://www.whois.com/whois

http://www.whois.com/

http://www.statsinfinity.com/

Изображения

http://www.tineye.com/

http://saucenao.com/

http://www.photobucket.com/

https://images.google.com/?gws_rd=ssl

IP2Skype

http://skypegrab.net/ip2skype.php

https://resolvethem.com/ip2skype.php

http://www.skresolver.com/ip-to-skype.php

http://mostwantedhf.info/ip2skype.php

https://www.hanzresolver.com/ip2skype

http://skype2ip.ninja/ip2skype.php

https://pkresolver.nl/ip2skype.php

http://www.chromeresolver.info/IP2Skype.php

 Email2Skype

http://mostwantedhf.info/email.php

http://www.skresolver.com/email-to-skype.php

https://www.hanzresolver.com/emaillookup

https://resolvethem.com/email.php

http://freetool.tk/email2skype.php

http://skypegrab.net/email2skype.php

Skype2Lan

http://www.skresolver.com/skype-to-lan.php

Skype2Email

http://skypegrab.net/skype2email.php

https://pkresolver.nl/skype2email.php

Поиск адреса MAC

http://www.coffer.com/mac_find/

http://www.whatsmyip.org/mac-address-lookup/

http://www.macvendorlookup.com/

http://macaddresslookup.org/

http://aruljohn.com/mac.pl

Lat / Long

http://www.latlong.net/

http://itouchmap.com/latlong.html

http://stevemorse.org/jcal/latlon.php

EXIF данные

http://exif-viewer.com/

http://metapicz.com/#landing

http://www.verexif.com/en/

http://www.findexif.com/

http://www.prodraw.net/online-tool/exif-viewer.php

http://exifdata.com/

 Регистраторы IP и скреппер

https://grabify.com

https://iplogger.com

http://blasze.com/

# не # пиять # содержание # Кали

Другое

http://www.abika.com/

http://www.freeality.com/

http://radaris.com/

http://twoogel.com/

http://www.advancedbackgroundchecks.com

http://www.spokeo.com/

http://www.peekyou.com/

http://yoname.com/

https://www.linkedin.com/

http://www.yellowpagesgoesgreen.org/

http://aad.archives.gov/aad/series-list.jsp?cat=GS29

http://www.numberway.com/uk/

https://www.vinelink.com/vinelink/initMap.do

http://www.jailbase.com/en/sources/fl-lcso/

http://publicrecords.onlinesearches.com/

https://www.Intelius.com/

http://www.zoominfo.com/s/#search

http://skipease.com/

https://www.advancedbackgroundchecks.com

http://www.PublicRecordsNow.com

🌎Другие новинки 2021 года🌎

Общий поиск:

Google

Ага. Однако убедитесь, что вы знаете своих операторов, чтобы извлечь из этого максимум пользы.

Bing

Хорошо, над Bing много высмеивают, поскольку он «также работает» рядом с Google, но у него есть несколько замечательных функций. Здесь работают многие операторы из Google, но я действительно понимаю, что только у Bing есть IP: для поиска других веб-сайтов на том же IP (развлечение с перекрестными ссылками на общем хосте).

Информация о сети, домене и маршрутизации

Большая часть этой страницы посвящена поиску информации о людях из социальных сетей, а не из сетевых. Однако иногда знание того, кто владеет сетью / доменом / IP-адресом, является отличным местом, поэтому начните, и люди оставляют в своих записях Whois вещи, которые могут выявить много полезных потенциальных клиентов. Сайтов, предлагающих такие услуги, очень много, но я остановлюсь только на своих любимых.

РобТекс

Хотя интерфейс, на мой взгляд, немного странный, это отличный сайт для выполнения обратного DNS-поиска по IP-адресам, захвата контактов Whois и поиска другой общей информации об IP или доменном имени.

ServerSniff

Этот какой-то странный мяч. Многие сайты предлагают информацию Whois, этот посвящен более экзотическим инструментам. Вам действительно нужно просто поиграть с ним, чтобы найти все его функции. Иногда бывает сложно вспомнить, какой вариант есть где. Вот лишь некоторые из инструментов: трассировки ICMP и TCP, информация SSL, отчеты DNS и имена хостов на общем IP. Если вы не хотите использовать прокси-сервер и не хотите, чтобы ваш IP-адрес отображался в журналах цели, было бы хорошо, если бы они провели некоторую разведку.

Ищу анкеты на человека

OSINT BOOKMARKLETS v0.2

Классная страница от Will Genovese, где вы можете автоматически искать информацию о телефоне, IP, хосте, электронной почте, серийном номере, имени и адресе.

Отличный сайт для поиска адресов и обозначения семейных отношений.

Семейное древо сейчас

Отличный сайт для поиска адресов и обозначения семейных отношений.

Корни лося

Отличный сайт, особенно для этих подсайтов

которые отлично подходят для определения семейных отношений при возникновении вопросов по сбросу пароля.

Расширенная проверка фона

Для поиска адресов и родственников это бомба. До сих пор это не подводило меня в поиске почтовых адресов, если у меня есть смутное представление о том, где кто-то живет.

Подглядывать за тобой

Интерфейс чистый, и хотя он ведет на платные сайты, он, по крайней мере, сначала дает вам реальную информацию. Кажется, я припоминаю, что раньше было лучше.

Луллар

Найдите человека, используя электронную почту | имя | имя пользователя. Возвращается не так много результатов, как на других сайтах, но то, что он дает, приятно чистое, без каких-либо проблем со всеми платными сайтами.

Проверить имена пользователей

Хорошо, должен сказать, что мне нравится этот сайт. Возможно, он не задумывался как сайт для профилирования, но он хорошо справляется с этой задачей. Мы все говорим о том, что повторное использование паролей является проблемой, но для профилирования кого-то повторное использование имени пользователя - вот где это. Этот сайт позволяет выполнять поиск по 160 сайтам социальных сетей, чтобы узнать, не используется ли псевдоним. Оттуда вы можете вручную увидеть, что находится в профиле людей на этих сайтах. Экономит время, стихи проверяя наличие учетной записи на каждом сайте самостоятельно, но вам еще предстоит много работы после этого.

KnowEm

Подобно проверке имен пользователей выше, но утверждает, что проверяет более 500 сайтов, чтобы узнать, занято ли данное имя пользователя.

я ищу

Раньше это был Спок («Единая точка контакта (по) ключевому слову»). Не уверен, когда это изменилось, я предполагаю, что это после того, как Intelius купил их. Вы можете искать по Имя | Телефон | Emai | Имя экрана. Думаю, неплохо для поиска родственников. Как только вы найдете имя по имени пользователя, вам следует сделать шаг назад и также поискать его, так как результаты сильно различаются. Кажется, в основном это побуждает людей платить деньги Intelius.

Пипл

Вы можете выполнить поиск по имени | электронной почте | имени пользователя | телефону и найти похожие результаты. Результаты могут быть очень шумными, со ссылками на кучу платных сайтов (Spokeo, Intellus и т. Д.), Но если вы готовы разбираться в чуши, это довольно приятно. Мне нравится то, что он показывает из публичных записей, профилей Amazon и социальных сетей.

123 человек

Как и все вышеперечисленное. Ссылки на множество других ресурсов, некоторые платные, а некоторые нет.

Spokeo

Хорошо, у Spokeo есть несколько хороших функций макета, но это информационная дразня. Он часто сообщает «эй, я кое-что нашел», но за результаты нужно платить. Как и преступление, я не плачу. Тем не менее, это может быть хорошей отправной точкой, которая приведет вас в другое место. Например, если вы знаете, что у кого-то есть профиль в Facebook, вы можете просто перейти на Facebook.

WebMii

Позволяет искать людей по имени или ключевому слову (попробуйте имя пользователя в качестве ключевого слова).

Информация о масштабировании

Кажется, неплохо найти, где кто-то работает. Интересно, сколько информации только из LinkedIn, а сколько из других источников? Если смотреть на них бок о бок, Zoom Info, кажется, дополняет детали другими источниками.

Географическое расположение

Карта Android

Если у вас есть MAC-адрес маршрутизатора (такое случается), у Сэми есть инструмент, который пытается определить его местоположение на основе того, что знает Google. Похоже, что Google использует телефон Android для распределенного wardrive, чтобы дополнить свои данные об автомобилях для просмотра улиц.

Приложения Bing Map

Приложения для карт - это неплохое дополнение, но вам понадобится SilverLight, и они не кажутся стабильными, если вы не используете Internet Explorer (см. Рисунок). Взгляните на приложение карты Twitter.

Карта Twitter

Также приятно видеть, откуда люди пишут твиты, но не так красиво и полно, как приложение Bing.

Мне повезло использовать это, чтобы найти адреса и соседей.

Google картинки

Я полагаю, что большинство людей знают об изображениях Google, но знаете ли вы, кто может загружать изображения (или перетаскивать их), чтобы получить аналогичные результаты? Подходит для поиска профилей под разными именами. Tin Eye похожа, но, похоже, не так много.

Оловянный глаз

Вы когда-нибудь находили чью-то фотографию и задавались вопросом, существует ли она где-нибудь еще? Tin Eye - это плагин для браузера, который позволяет выбрать картинку и найти похожие в Интернете, даже те, которые были серьезно проданы. К сожалению, база данных кажется маленькой. Я надеюсь зайти в профиль социальной сети, щелкнуть правой кнопкой мыши изображение, имя пользователя которого я знаю только, а затем найти другие профили с настоящим именем и более подробной информацией. До сих пор это было в основном полезно для выяснения, «кто этот актер / модель», но, возможно, в будущем это будет лучше.

Открытая книга

Должен любить людей, которые оставляют комментарии в Facebook открытыми для всего мира. Даже если один человек осведомлен о конфиденциальности, его друг может не быть и не может комментировать его.

Открыть поиск по статусу

Open Book, кажется, больше не существует, и Open Status Search кажется следующим лучшим вариантом.

Пик Туман

Может найти что-то хорошее, может найти то, что ранит вас на всю жизнь.

Белые страницы Найдите соседей

Может быть полезно, если вам нужно обратиться к кому-нибудь поблизости.

Ясни

Мне очень повезло, если я использовал это для сбора информации о людях.

Archive.org Wayback Machine

Иногда кто-то бросает свои документы, но удаляет их. Wayback Machine может помочь вам найти удаленную информацию.

Читатель Доски

Может быть, человек публикует сообщения на каких-то форумах с заданным именем пользователя? Может привести к полезной информации.

OMGili

Другой поиск по доске, как указано выше.

Инструменты

Хорошо, это не веб-сайты, а чертовски полезные инструменты, которые черпают из веб-ресурсов.

Мальтего

Отличный инструмент, и мне нравится, как он рисует связи между сущностями, такими как имя, домен, адреса электронной почты и т. Д., Что хорошо для построения карты разума того, как все взаимосвязано. Я по-прежнему предпочитаю делать что-то вручную, чтобы устранять ложные срабатывания и интерпретировать данные. Вам, вероятно, придется зарегистрироваться для получения ключей API, чтобы получить от него максимальную пользу.

NetGlub

Когда-нибудь это может стать заменой Maltego с открытым исходным кодом, но сейчас кажется почти невозможным приступить к работе.

Foca

Я действительно копаюсь в этих инструментах. Он может выполнять поиск распространенных форматов документов с помощью Google и других поисковых систем, а затем загружать их для извлечения метаданных. Прекрасный.

https://www.elevenpaths.com/labstools/foca/index.htmlCree.py

Отличный инструмент для геолокации / отслеживания пользователей Twitter / Foursquare. Не только извлекает координаты напрямую из сообщений, но также может извлекать их из данных EXIF в изображениях, на которые они ссылаются.

http://intelx.io/

http://haveibeenpwned.com/

http://ekata.com/

http://dehashed.com/

http://whitepages.com

http://thatsthem.com

http://emailrep.io/

https://github.com/khast3x/h8mail

https://github.com/Cat-Linux/BeaverRecon

▬ι═ I ═S═ P══TOOLS═════ι▬▬

AT&T - http://www.att.com/

Служба поддержки U-verse: 1-800-288-2020

Идентификаторы сотрудников - md905c

• Системы: G2, CCTP, SystemX, Clarify, Telegence, MyCSP, Phoenix,

Torch, CSR Admin, CTI, система проверки агентов, CCC Tool, DLC, C-Care

Небо - http://www.sky.com/

Служба поддержки Sky: 0-844-241-1653

• Системы: Облако

Кокс - http://ww2.cox.com/residential/home.cox

Поддержка Cox: 877-891-2899 • Системы: Polaris (IP), iNav, edgehealth, Icon, IDM, ICOMS, SL2

Устав - https://www.charter.com/

Чартерная поддержка: 713-554-3669

• Системы: Sigma (запросите это для поиска), IRIS

Comcast - http://www.comcast.com/

Служба поддержки Comcast: 1-800-934-6489

• Системы: ACSR, Comtrac, CSG, Einstein, Grand-slam (Спросите об этом для

поиски), видение

Тайм Уорнер - http://www.timewarnercable.com/

Служба поддержки Time Warner - 212-364-8300

• Системы: Real, Unify (Спросите об этом для поиска)

Дорожный бегун - http://www.rr.com/

Служба поддержки Road Runner: 1-866-744-1678

• Системы: Real, Unify

Verizon - http://www.verizonwireless.com/

Служба поддержки Verizon: 1-800-837-4966

▬▬ι═══════ ﺤ -═══════ι▬▬

Предметы, которые можно найти:

Имя в файле:

Дата рождения:

SSN в файле:

Телефон в досье:

Адрес в файле:

Номер учетной записи интернет-провайдера:

Адрес электронной почты основного аккаунта

REGARDS = @ its_me_kali

INSTAGRAM OSINT

Osintgram - это инструмент OSINT в Instagram. Osintgram - это ответвление https://github.com/LevPasha/Instagram-API-pythonи https://github.com/woj-ciech/OSINT/tree/master/insta.

Я не беру на себя ответственность за использование этого инструмента.

Osintgram предлагает интерактивную оболочку для анализа учетной записи Instagram любого пользователя по его нику. Ты можешь получить:

- информация Получить информацию о цели - адресаты Получить все зарегистрированные, адресованные целевыми фотографиями - подписчики Получить целевых подписчиков - подписаться Получить пользователей, за которыми следует цель - хэштеги Получить хэштеги, используемые целью - лайки Получить общее количество лайков публикациям цели - комментарии Получить общее количество комментариев к сообщениям цели - tagged Получить список пользователей, помеченных целью - photodes Получить описание фотографий

цели - фотографии Загрузить фотографии пользователя в папку вывода - подписи Получить подписи к фотографиям пользователя - mediatype Получить тип сообщений пользователя (фото или видео) - propic Загрузить изображение профиля пользователя - истории Загрузить пользователя истории

Установка

Fork / Clone / Загрузите этот клон репогита https://github.com/Datalux/Osintgram.git

Перейдите в каталог cd Osintgram

Запустите pip3 install -r requirements.txt

Создайте подкаталог configmkdir config

Создайте в config папку файл: username.conf и напишите свой логин в Instagram.

Создайте в config папку файл: pw.conf и напишите пароль своего аккаунта в Instagram.

Запустите сценарий main.py python3 main.py <целевое имя пользователя>

Обновление

Запустите git pull в каталоге Osintgram

🍊🍊Другой инструмент🍊🍊

Установка

git clone https://github.com/sc1341/InstagramOSINT.git

cd InstagramOSINT

pip3 install -r requirements.txt

Использовать

python3 main.py –username ИМЯ ПОЛЬЗОВАТЕЛЯ

Instagram OSINT

Обратите внимание, что InstagramOSINT.py предназначен для импорта в качестве модуля python, он предназначен для использования в пользовательских приложениях, а не для запуска из командной строки.

Использование API InstagramOSINT.py

Это полезно при попытке применить эту кодовую базу к любым проектам. API действительно прост в использовании и использует функции Python, чтобы упростить его использование, например индексацию.

Примеры:

из InstagramOSINT import * instagram = InstagramOSINT (username = ’USERNAMEHERE’) print (instagram.profile_data) print (instagram [‘Username’]) instagram.print_profile_data () instagram.save_data () instagram.scrape_posts ()

FB OSINT 

OSINT для аккаунта Facebook

1. graph.tips - позволяет посмотреть, как публикации ставят лайки пользователя

2. whopostedwhat.com - поиск сообщений в Facebook.

3. fb-the sleep-the stats (t) - отслеживает онлайн / офлайн статус людей, вы можете получить точную информацию о времени их сна.

4. lookup-id.com - будет ID аккаунта

5. keyhole.co (r) - анализ аккаунта, без проверки почты и телефона при регистрации, вводите любые данные, 7 дней бесплатно

6. archive.org - показать заархивированную версию аккаунта

7. @ usersbox_bot - бот найдет аккаунты ВКонтакте с желаемым логином в поле facebook @GetPhone_bot - найдет номер телефона в своей базе данных. Поиск по URL 1. https://www.facebook.com/browse/fanned_pages/?id=USERID - найдет лайки пользователя, заменит на идентификатор учетной записи 2. https://facebook.com/friendship/USERID/USERID - общие друзья, общие записи будут быть отображенными и фотографии, а также любые другие связанные данные, такие как родные города, школы и т. д., заменить на идентификатор учетной записи 3.facebook: <Login>

ID ПОЛЬЗОВАТЕЛЯ

ID ПОЛЬЗОВАТЕЛЯ

https://facebook.com/browse/mutual_friends/?uid=USERID&node=USERID - найдет общих друзей, у которых есть общедоступные списки друзей; если у одного из искомых пользователей есть общедоступный список друзей, замените USERID идентификатором учетной записи

Поиск по URL

4. https: //my.mail.ru/fb/USERID - найдет аккаунт в Моем Мире, замените USERID в ссылке на ID аккаунта.

дополнение:
Мощный инструмент для пробива информации по номеру(мультисервисы)Ф

https://github.com/sundowndev/PhoneInfoga

Sherlock
Самый мощный известный мне инструмент по пробиву ника

https://github.com/sherlock-project/sherlock

Photon
Очень сильный кравлер(Выгрузка информации с сайтов)

https://github.com/s0md3v/Photon

Библия пентестера
Крупнейший сборник информации по пентесту, что тебе пригодится в будущем.Информация на английском, и информации настолько дохуя, что эге по английскому языку ты сдашь на нехуй делать.

https://github.com/blaCCkHatHacEEkr/PENTESTING-BIBLE

Если же тебе это нахуй не интересно, держи материал с этой библии для OSINT

4500 гугл дорков — https://sguru.org/ghdb-download-list-4500-google-dork..

OSINT Ресурсы 2019 — https://medium.com/p/b15d55187c3f

OSINT Тулкит — https://medium.com/@micallst/osint-resources-for-2019..

Визуализация информации OSINT — https://medium.com/hackernoon/osint-tool-for-visualiz..

Instagram OSINT — https://medium.com/secjuice/what-a-nice-picture-insta..

Наилучший сборник OSINT
https://github.com/jivoi/awesome-osint

СЛОЖНЕЙШИЙ ИНСТРУМЕНТ SPIDERFOOT(Lampyre Lighthouse на стероидах)
https://github.com/smicallef/spiderfoot

Для тебя это будет заданием — поставить эту хуету, и подключить все бесплатные API

Общий OSINT GitHub топик
https://github.com/topics/osint


''')
