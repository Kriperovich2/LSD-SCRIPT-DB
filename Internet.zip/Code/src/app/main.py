import os
from colorama import init 
import ctypes
from colorama import Fore
from pystyle import Colorate, Colors, Center
from pystyle import *
from search import stalin, helix_number, peremena, phone0, celevay, phone1, p2hone1, negr, wb, good_eye, alfa_bank, alfa_qwe, ior, nekr, helper, klsaas, msiafter, kletka, gena, roda, litra, tarakan, vedro, brat, neznau, mnelen, univer, sbc, mucl1, mucl2, mucl3, mucl5, mucl6, mucl4, mucl7, gaz, dns, spasibo, spasibo2, zatr, pidr, love, ebat, ebat1, ebat3, ebat2, ebat4, ebat5, ebat6, ebat7, ebat8, ebat9
enter = Colorate.Horizontal(Colors.white_to_blue, ('[!] To Continue Press "Enter" ↓'))


def set_title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)


if __name__ == "__main__":
    Internet_Dox_Title = "t.me/NetStore_robot"
    set_title(Internet_Dox_Title)

    
intro = (
'                                                                                                 \n' 
'     ▄█  ███▄▄▄▄       ███        ▄████████    ▄████████ ███▄▄▄▄      ▄████████     ███          \n'
'    ███  ███▀▀▀██▄ ▀█████████▄   ███    ███   ███    ███ ███▀▀▀██▄   ███    ███ ▀█████████▄      \n'
'    ███▌ ███   ███    ▀███▀▀██   ███    █▀    ███    ███ ███   ███   ███    █▀     ▀███▀▀██      \n'
'    ███▌ ███   ███     ███   ▀  ▄███▄▄▄      ▄███▄▄▄▄██▀ ███   ███  ▄███▄▄▄         ███   ▀      \n'
'    ███▌ ███   ███     ███     ▀▀███▀▀▀     ▀▀███▀▀▀▀▀   ███   ███ ▀▀███▀▀▀         ███          \n'
'    ███  ███   ███     ███       ███    █▄  ▀███████████ ███   ███   ███    █▄      ███          \n'
'    ███  ███   ███     ███       ███    ███   ███    ███ ███   ███   ███    ███     ███          \n'
'    █▀    ▀█   █▀     ▄████▀     ██████████   ███    ███  ▀█   █▀    ██████████    ▄████▀        \n'
'                                              ███    ███                                         \n'
'                         Welcome to Multi Tool Internet. To Continue Press "Enter"               \n'
'                                      Telegram: NetStore_robot                                   \n'
)
print(Colorate.Horizontal(Colors.white_to_blue, Center.XCenter(intro)))

def clear_screen():
    os.system("cls")


if __name__ == "__main__":
    clear_screen()


if __name__ == "__main__":
    clear_screen()


Anime.Fade(
    Center.Center(intro),
    Colors.white_to_blue,
    Colorate.Vertical,
    interval=0.045,
    enter=True,
)

while True:    
    def se2t_title(titl2e):
      ctypes.windll.kernel32.SetConsoleTitleW(titl2e)

    if __name__ == "__main__":
        Internet_Dox_Tool = "Internet Tool"
        se2t_title(Internet_Dox_Title)

    def clear_screen():
        os.system("cls")

    if __name__ == "__main__":
        clear_screen()

    from banner import banner                  
    print()
    print(Colorate.Horizontal(Colors.white_to_blue, Center.XCenter(banner)))
    


    COLOR_CODE = {
        "BLUE": "\033[34m",
        "BOLD": "\033[01m",
        "RESET": "\033[0m",
    }

    text = f'{COLOR_CODE["BLUE"]}[$]{COLOR_CODE["BOLD"]} Введите функцию'
    text2 = f"{text}{COLOR_CODE['BLUE']}: {COLOR_CODE['RESET']}"

    select = input(text2)

    if select == '1':
        contact = 'Базы\data.csv' 
        file = 'Базы\data1.csv' 
        file1 = 'Базы\data2.csv' 
        file2 = 'Базы\data3.csv' 
        file3 = 'Базы\data4.csv' 
        file4 = 'Базы\data5.csv'  
        file6 = 'Базы\data6.csv'
        file7 = 'Базы\data7.csv'
        good = 'Базы\data8.csv'
        satoshibd = 'Базы\data9.csv'  
        data_base = 'Базы\data10.csv' 
        alfa = 'Базы\data11.csv' 
        fl = 'Базы\data12.csv' 
        arram = 'Базы\data14.csv'
        asd = 'Базы\data16.csv'
        pauset = 'Базы\data17.csv'
        helix_db = 'Базы\data18.csv'
        satoshimatra = 'Базы\data19.csv'
        getandnumb = 'Базы\data20.csv'
        para = 'Базы\data21.csv'
        para2 = 'Базы\data22.csv'
        para3 = 'Базы\data23.csv'
        para4 = 'Базы\data24.csv'
        para5 = 'Базы\data25.csv'
        para7 = 'Базы\data26.csv'
        para8 = 'Базы\data27.csv'
        para9 = 'Базы\data28.csv'
        para10 = 'Базы\data29.csv'
        para11 = 'Базы\data30.csv'
        notsbj = 'Базы\data32.csv'
        file8 = 'Базы\data44.txt'
        file9 = 'Базы\data45.txt'
        file10 = 'Базы\data46.txt'
        file11 = 'Базы\data47.txt'
        file12 = 'Базы\data48.txt'
        file13 = 'Базы\data49.txt'
        file14 = 'Базы\data51.txt'
        file15 = 'Базы\data53.txt'
        file16 = 'Базы\data54.txt'
        file17 = 'Базы\data55.txt'
        file18 = 'Базы\data56.txt'
        file19 = 'Базы\data57.txt'
        file20 = 'Базы\data58.txt'
        file21 = 'Базы\data59.txt'
        file22 = 'Базы\data60.txt'
        file23 = 'Базы\data61.txt'
        file24 = 'Базы\data62.txt'
        file25 = 'Базы\data63.txt'
        file26 = 'Базы\data64.txt'
        file27 = 'Базы\data65.txt'
        file28 = 'Базы\data66.csv'
        file29 = 'Базы\data67.csv'
        file30 = 'Базы\data68.txt'
        file31 = 'Базы\data69.csv'
        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
              ''')
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите номер телефона: {COLOR_CODE["RESET"]}')

        found_in_main_db = stalin(file, search_value) 

        if not found_in_main_db:  
            found_in_bel3_db = helix_number(helix_db, search_value)

        if not found_in_bel3_db:  
            found_in_bel4_db = peremena(file1, search_value) 

        if not found_in_bel4_db:
            found_in_bel5_db = phone0(file2, search_value) 

        if not found_in_bel5_db:   
           found_in_belu_db = celevay(file7, search_value)

        if not found_in_belu_db:  
           found_in_bel7_db = phone1(file3, search_value) 

        if not found_in_bel7_db:  
           found_in_bel8_db = p2hone1(file4, search_value)

        if not found_in_bel8_db:   
           found_in_bel9_db = negr(file6, search_value)

        if not found_in_bel9_db:   
           found_in_bel10_db = wb(fl, search_value) 

        if not found_in_bel10_db:    
           found_in_bel12_db = good_eye(good, search_value) 

        if not found_in_bel12_db:    
           found_in_bel13_db = alfa_bank(alfa, search_value)  

        if not found_in_bel13_db:   
           found_in_bel14_db = alfa_qwe(arram, search_value)

        if not found_in_bel14_db:    
           found_in_bel16_db = ior(asd, search_value)

        if not found_in_bel16_db:  
           found_in_bel17_db = nekr(pauset, search_value)  

        if not found_in_bel17_db:     
            satanasuka = klsaas (satoshibd, search_value) 

        if not satanasuka:
            goderpythonsuska = helper (satoshimatra, search_value)    

        if not goderpythonsuska:
            found_in_belpon_db = msiafter (getandnumb, search_value)  

        if not found_in_belpon_db:
            found_in_bel19_db = kletka (para, search_value)

        if not found_in_bel19_db:
            found_in_bel20_db = gena (para2, search_value)

        if not found_in_bel20_db:
            found_in_bel21_db = roda (para3, search_value)

        if not found_in_bel21_db:
            found_in_bel22_db = litra (para4, search_value)

        if not found_in_bel22_db:
            found_in_bel23_db = tarakan (para5, search_value)

        if not found_in_bel23_db:
            found_in_bel24_db = vedro (para7, search_value) 

        if not found_in_bel24_db:
            found_in_bel25_db = brat (para8, search_value)

        if not found_in_bel25_db:
            found_in_bel26_db = mnelen (para9, search_value)   

        if not found_in_bel26_db:
            found_in_bel27_db = neznau (para10, search_value)

        if not found_in_bel27_db:
            found_in_bel28_db = univer (para11, search_value) 

        if not found_in_bel28_db:
            found_in_bel29_db = sbc (notsbj, search_value)      

        if not found_in_bel29_db:
            found_in_belline1_db = mucl1 (file9, search_value) 

        if not found_in_bel29_db:
            found_in_belline1_db = mucl2 (file10, search_value)

        if not found_in_bel29_db:
            found_in_belline1_db = mucl3 (file11, search_value)

        if not found_in_bel29_db:
            found_in_belline1_db = mucl4 (file12, search_value)

        if not found_in_bel29_db:
            found_in_belline1_db = mucl5 (file13, search_value) 

        if not found_in_bel29_db:
            found_in_belline1_db = mucl6 (file8, search_value)  

        if not found_in_bel29_db:
            found_in_belline1_db = mucl7 (file14, search_value)

        if not found_in_belline1_db:
            found_in_private_db = gaz (file15, search_value) 

        if not found_in_private_db:
            found_in_pri2ate_db = dns (file16, search_value)   

        if not found_in_pri2ate_db:
            sber = spasibo (file17, search_value) 

        if not sber:
            sbergo = spasibo2 (file18, search_value)

        if not sbergo:
            found = zatr (file19, search_value)  

        if not found:
            found1 = pidr (file20, search_value)  

        if not found1:
            found2 = love (file21, search_value)   

        if not found2:
            found3 = ebat (file22, search_value)

        if not found3:
            found4 = ebat1 (file23, search_value)

        if not found4:
            found5 = ebat2 (file24, search_value)

        if not found5:
            found6 = ebat3 (file25, search_value)

        if not found6:
            found7 = ebat4 (file26, search_value)

        if not found7:
            found8 = ebat5 (file27, search_value)

        if not found8:
            found9 = ebat6 (file28, search_value)

        if not found9:
            found10 = ebat7 (file29, search_value)  

        if not found10:
            found11 = ebat8 (file30, search_value)  

        if not found11:
            found12 = ebat9 (file31, search_value)                     
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '2':
        from mail import piska, xyina, xyeta, blyad, syka, nevoryicode, iiiop, jopa
        file6 = 'Базы\data33.csv'
        file5 = 'Базы\data34.csv'
        file = 'Базы\data1.csv' 
        file1 = 'Базы\data2.csv'
        file2 = 'Базы\data3.csv'
        file3 = 'Базы\data4.csv'
        file4 = 'Базы\data5.csv'
        filesuka = 'Базы\data44.csv'
        fileblyad = 'Базы\data48.txt'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите почту: {COLOR_CODE["RESET"]}')

        found_in_yandex_db = piska(file5, search_value)

        if not found_in_yandex_db:
            found_in_xyina_db = xyina(file, search_value)

        if not found_in_xyina_db:
            found_in_xyeta_db = xyeta(file1, search_value)

        if not found_in_xyeta_db:
            found_in_blyad_db = blyad(file2, search_value) 

        if not found_in_blyad_db:
            found_in_syka_db = syka(file3, search_value)

        if not found_in_syka_db:
            found_in_nevoryicode_db = nevoryicode(file4, search_value)   

        if not found_in_nevoryicode_db:
            found_in_coder_db = iiiop(filesuka, search_value)  

        if not found_in_coder_db:
            found_in_eblan_db = jopa(fileblyad, search_value)        

        input("Нажмите Enter, чтобы продолжить...")

    elif select == '3':
        from probivcards import kotily
        son = 'Базы\data35.csv'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите номер карты: {COLOR_CODE["RESET"]}')

        found_in_ynula = kotily(son, search_value)
        input("Нажмите Enter, чтобы продолжить...")    

    elif select == '4':
        from get_ip import get_ip
        get_ip()
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '9':
        from probivface import interbb
        facebb = 'Базы\data36.csv'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите id facebook: {COLOR_CODE["RESET"]}')

        found_in_ynula = interbb(facebb, search_value)
        input("Нажмите Enter, чтобы продолжить...")   

    elif select == '19':
        from geninn import generate_inn
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '21':
        from ukphone import generate_phone
        input("Нажмите Enter, чтобы продолжить...") 

    elif select == '10':
        from inndean import ukura
        inn = 'Базы\data50.txt'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите ИНН: {COLOR_CODE["RESET"]}')

        found_in_ynula = ukura(inn, search_value)
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '11':
        from logdean import pizda, cep, cuka
        lgin = 'Базы\data48.txt'
        log = 'Базы\data51.txt'
        mot = 'Базы\data54.txt'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите логин: {COLOR_CODE["RESET"]}')

        found_in_ynula = pizda(lgin, search_value)

        if not found_in_ynula:
            found_in_eblan_db = cep(log, search_value) 

        if not found_in_eblan_db:
            iyabel = cuka(mot,search_value)   
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '12':
        from pasdean import internet
        pas = 'Базы\data52.txt'

        os.system("cls")

        print(f'''{COLOR_CODE["BLUE"]}
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                            
                   ''')      
        search_value = input(f'{COLOR_CODE["BLUE"]}[$] Введите пароль: {COLOR_CODE["RESET"]}')

        found_in_ynula = internet(pas, search_value)
        input("Нажмите Enter, чтобы продолжить...")            

    elif select == '!':
        from ddos import dos
        dos()    
    elif select == '20':
        from rusphone import generate_phone_number
        input("Нажмите Enter, чтобы продолжить...")                     

    elif select == '6':
        from get_id import juniper, pidor_id
        sanyacoder = 'Базы\data37.csv'
        telegram_base = 'Базы\data38.txt'
        os.system("cls")
        print(f'''{COLOR_CODE["BLUE"]}                                                                                                                    
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                              
                           '                          '             '                                                        
                   ''')      
        search_value = input('{}[$] Введите id telegram: {}'.format(COLOR_CODE["BLUE"], COLOR_CODE["RESET"]))
        found_in_farmer_bd = juniper(sanyacoder, search_value)

        if not found_in_farmer_bd:
            found_in_shkav_db = pidor_id(telegram_base, search_value)   

    elif select == '7':
        from vkontakte import vkbd, vksuk
        vkdad = 'Базы\data39.csv'
        vknorm = 'Базы\data53.txt'
        os.system("cls")
        print(f'''{COLOR_CODE["BLUE"]}                                                                                                                    
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                                                                
                   ''')      
        search_value = input('{}[$] Введите id vk: {}'.format(COLOR_CODE["BLUE"], COLOR_CODE["RESET"]))
        found_in_burger_bd = vkbd(vkdad, search_value)

        if not found_in_burger_bd:
            opium = vksuk(vknorm, search_value)
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '5':
        from fio import fiobd
        fiobad = 'Базы\data40.csv'
        os.system("cls")
        print(f'''{COLOR_CODE["BLUE"]}                                                                                                                    
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                                                              
                   ''')      
        search_value = input('{}[$] Введите Фамилию Имя Отчество: {}'.format(COLOR_CODE["BLUE"], COLOR_CODE["RESET"]))
        found_in_file_bd = fiobd(fiobad, search_value)
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '8':
        from snils import jokeybd
        zxcbad = 'Базы\data41.csv'
        os.system("cls")
        print(f'''{COLOR_CODE["BLUE"]}                                                                                                                    
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                                                              
                   ''')      
        search_value = input('{}[$] Введите СНИЛС: {}'.format(COLOR_CODE["BLUE"], COLOR_CODE["RESET"]))
        found_in_file_bd = jokeybd(zxcbad, search_value)
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '25':
        import anonim
        input("Нажмите Enter, чтобы продолжить...") 

    elif select == '16':
        from genmail import generate_email
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '17':
        from genpasswd import generate_password
        input("Нажмите Enter, чтобы продолжить...")   

    elif select == '18':
        from gensnils import generate_snils
        input("Нажмите Enter, чтобы продолжить...")              

    elif select == '26':
        import dox
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '27':   
        import osint
        input("Нажмите Enter, чтобы продолжить...") 

    elif select == '14':
        import mullvad
        input("Нажмите Enter, чтобы продолжить...")    

    elif select == '13': 
        import passports 
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '31': 
        import bots 
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '32': 
        import block 
        input("Нажмите Enter, чтобы продолжить...")

    elif select == '33': 
        import swat 
        input("Нажмите Enter, чтобы продолжить...")             
                
    elif select == '15':
        import gencards
        input("Нажмите enter для продолжения")
        

    elif select == '28':
        import deanon
        input("Нажмите enter для продолжения")

    elif select == '30':
        import snonvk
        input("Нажмите enter для продолжения")  

    elif select == '29':
        import snostg
        input("Нажмите enter для продолжения")      

    elif select == '?':
        os.system("cls")
        print(f'''{COLOR_CODE["BLUE"]}                                                                                                                    
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                                                                  
                   ''')
        print(f'''{COLOR_CODE["BLUE"]}     
         
        Intenet - Это абсолютно новый поисковик данных который поможет вам наказать вашего обидчика.                                                                                                                                                                                                              
        Учтите что использование данной программы сугубо нарушает законы СНГ стран, автор не несёт никакой ответственности за ваши действия.                                
        Данная программа лишь фантазия автора.                                                                                                                              
        
        Crypto bot: https://t.me/send?start=IVEMkzee3CfS
        Спасибо за донат <3
              
        Developer: @KPACH0V      
        ''')   

    elif select == '22':
        from genmac import generate_mac
        input("Нажмите Enter, чтобы продолжить...")    

    elif select == '24':
        from genip import generate_ip  
        input("Нажмите Enter, чтобы продолжить...") 

    elif select == '23':
        from genfake import generate_fake_person 
        input("Нажмите Enter, чтобы продолжить...")        
    
    elif select == '99':
        exit()
                                     
    else:
        print(f'{COLOR_CODE["BLUE"]}Неверный выбор, попробуйте снова!{COLOR_CODE["RESET"]}')
    input("Нажмите Enter, чтобы продолжить...")

    


