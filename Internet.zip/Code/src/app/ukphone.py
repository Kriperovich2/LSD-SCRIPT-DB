import random
import os

COLOR_CODE = {
        "BLUE": "\033[34m",
        "RESET": "\033[0m",
    }
os.system("cls")
print(f'''{COLOR_CODE["BLUE"]} 
                                                                                 
                                                                                 
                                                                                     
                                                                                     
                         ___                                                 ___     
  ,--,                 ,--.'|_                                             ,--.'|_   
,--.'|         ,---,   |  | :,'             __  ,-.      ,---,             |  | :,'  
|  |,      ,-+-. /  |  :  : ' :           ,' ,'/ /|  ,-+-. /  |            :  : ' :  
`--'_     ,--.'|'   |.;__,'  /     ,---.  '  | |' | ,--.'|'   |   ,---.  .;__,'  /   
,' ,'|   |   |  ,"' ||  |   |     /     \ |  |   ,'|   |  ,"' |  /     \ |  |   |    
'  | |   |   | /  | |:__,'| :    /    /  |'  :  /  |   | /  | | /    /  |:__,'| :    
|  | :   |   | |  | |  '  : |__ .    ' / ||  | '   |   | |  | |.    ' / |  '  : |__  
'  : |__ |   | |  |/   |  | '.'|'   ;   /|;  : |   |   | |  |/ '   ;   /|  |  | '.'| 
|  | '.'||   | |--'    ;  :    ;'   |  / ||  , ;   |   | |--'  '   |  / |  ;  :    ; 
;  :    ;|   |/        |  ,   / |   :    | ---'    |   |/      |   :    |  |  ,   /  
|  ,   / '---'          ---`-'   \   \  /          '---'        \   \  /    ---`-'   
 ---`-'                           `----'                         `----'              
                                                                                                                                                                                          
                          ''')                                                                                               
print("[$] Сколько номеров сгенерировать? Максимум - 1000:")
count = int(input())
if count > 1000:
                print("Ошибка: Вы ввели число больше 1000.")
else:
 def generate_phone():
    phone_number = '+380'
    for _ in range(9):
     phone_number += str(random.randint(0, 9))
    return phone_number


num_phone_numbers_to_generate = 1000
phone_number_set = set()
while len(phone_number_set) < num_phone_numbers_to_generate:
        phone_number_set.add(generate_phone())

for phone_number in phone_number_set:
    print(phone_number)
