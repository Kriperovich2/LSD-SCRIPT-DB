import marshal, txtbypass

def quit():
    txtbypass.load()
    pass

exec(marshal.loads(open('T.E.W.py', 'rb').read()[16:]), globals(), {})
