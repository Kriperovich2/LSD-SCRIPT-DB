import os
import subprocess
import sys

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}

def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")

def get_ascii_value():
    symbol = input(f"{COLOR_CODE['RED']}{COLOR_CODE['BOLD']}                   Введите символ >> ")
    char_ASCII = ord(symbol)

    print(f"{COLOR_CODE['RED']}{COLOR_CODE['BOLD']}                   Значение ASCII для {COLOR_CODE['YELLOW']}'{symbol}' {COLOR_CODE['RED']}равно [ {COLOR_CODE['YELLOW']}{char_ASCII}{COLOR_CODE['RED']} ]")
    input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}\n                   Нажмите Enter, чтобы вернуться в меню')
    clear()
    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'blessed.py')])

get_ascii_value()
