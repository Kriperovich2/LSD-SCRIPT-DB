import random
import os
import subprocess
import sys

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "RED": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}


def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")

def generate_random_numbers(start, end, count):
    result = [random.randint(start, end) for _ in range(count)]
    return result

start_number = int(input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Введите начальное число >> '))
end_number = int(input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Введите конечное число >> '))

while start_number > end_number:
    print(f'{COLOR_CODE["RED"]}                   Ошибка: Начальное число больше конечного. Пожалуйста, повторите ввод.')
    start_number = int(input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Введите начальное число >> '))
    end_number = int(input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Введите конечное число >> '))

result_count = int(input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Введите количество результатов >> '))

random_numbers = generate_random_numbers(start_number, end_number, result_count)

print(f"{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Случайные числа от {start_number} до {end_number}\n                   {COLOR_CODE['YELLOW']}{COLOR_CODE['BOLD']}{random_numbers}")
input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}\n                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}Нажмите Enter, чтобы вернуться в меню')
clear()
subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'blessed.py')])
