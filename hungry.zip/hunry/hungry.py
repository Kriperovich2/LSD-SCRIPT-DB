import subprocess
import os
import sys
from colorama import init
from pystyle import *


COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}


def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")


banner = r'''
             ██░ ██  █    ██  ███▄    █   ▄████  ██▀███  ▓██   ██▓
            ▓██░ ██▒ ██  ▓██▒ ██ ▀█   █  ██▒ ▀█▒▓██ ▒ ██▒ ▒██  ██▒
            ▒██▀▀██░▓██  ▒██░▓██  ▀█ ██▒▒██░▄▄▄░▓██ ░▄█ ▒  ▒██ ██░
            ░▓█ ░██ ▓▓█  ░██░▓██▒  ▐▌██▒░▓█  ██▓▒██▀▀█▄    ░ ▐██▓░
            ░▓█▒░██▓▒▒█████▓ ▒██░   ▓██░░▒▓███▀▒░██▓ ▒██▒  ░ ██▒▓░
             ▒ ░░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒  ░▒   ▒ ░ ▒▓ ░▒▓░   ██▒▒▒ 
             ▒ ░▒░ ░░░▒░ ░ ░ ░ ░░   ░ ▒░  ░   ░   ░▒ ░ ▒░ ▓██ ░▒░ 
             ░  ░░ ░ ░░░ ░ ░    ░   ░ ░ ░ ░   ░   ░░   ░  ▒ ▒ ░░  
             ░  ░  ░   ░              ░       ░    ░      ░ ░     
                                                          ░ ░     

                                @ReaperSoft
                               Главное меню
                               
                   ┌─────Осинт─────┐   ┌──────Прочее─────────┐          
                   │  1 | Номер    │   │  5 | форм текст     │      
                   │  2 | Почта    │   │  6 | Единицы памяти │
                   │  3 | Юз       │   │  7 | Рандом номер   │
                   │  10| Бд       │   │  8 | ASCII VALUE    │ 
                   └───────────────┘   └─────────────────────┘         
     
                           ┌─────────────────┐   
                           │    0 | выход    │   
                           └─────────────────┘   

'''

print(Colorate.Vertical(Colors.white_to_red, Center.XCenter(banner)))

select = input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}\n'
               f'                   >> ')

if select == '1':
    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'osintnumber.py')])

if select == '2':
    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'osintmail.py')])

if select == '3':
    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'osintuser.py')])

if select == '10':
    print(f"{COLOR_CODE['RED']}                      DATABASE -")
    print(f"{COLOR_CODE['RED']}                     [+]{COLOR_CODE['RESET']}Большая Перемена")
    print(f"{COLOR_CODE['RED']}                     [+]{COLOR_CODE['RESET']}Гоуслуги")
    print(f"{COLOR_CODE['RED']}                     [+]{COLOR_CODE['RESET']}Гетконтакт")
    print(f"{COLOR_CODE['RED']}                     [+]{COLOR_CODE['RESET']}SPORT-UA")
    print(f"{COLOR_CODE['RED']}                     [+]{COLOR_CODE['RESET']}PRO SUSHI")
    input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
    clear()
    



elif select == '0':
    exit()

elif select == '5':
    from textgen import input_text, transform_text

    transform_text(input_text)

elif select == '6':
    from memory_size import convert_to_bits, input_str

    convert_to_bits(input_str)

elif select == '7':
    from gen import generate_random_numbers, start, end, count

    generate_random_numbers(start, end, count)

elif select == '8':
    from ascii import get_ascii_value

    get_ascii_value()
