import os
import subprocess
import sys
import time

from pystyle import *

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}


def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")


banner = r'''
▀█████████▄   ▄█          ▄████████    ▄████████    ▄████████    ▄████████ ████████▄  
  ███    ███ ███         ███    ███   ███    ███   ███    ███   ███    ███ ███   ▀███ 
  ███    ███ ███         ███    █▀    ███    █▀    ███    █▀    ███    █▀  ███    ███ 
 ▄███▄▄▄██▀  ███        ▄███▄▄▄       ███          ███         ▄███▄▄▄     ███    ███ 
▀▀███▀▀▀██▄  ███       ▀▀███▀▀▀     ▀███████████ ▀███████████ ▀▀███▀▀▀     ███    ███ 
  ███    ██▄ ███         ███    █▄           ███          ███   ███    █▄  ███    ███ 
  ███    ███ ███▌    ▄   ███    ███    ▄█    ███    ▄█    ███   ███    ███ ███   ▄███ 
▄█████████▀  █████▄▄██   ██████████  ▄████████▀   ▄████████▀    ██████████ ████████▀  
             ▀                                                                        
                           own: @deathrebootxpvp 



'''

print(Colorate.Vertical(Colors.white_to_red, Center.XCenter(banner)))


def loading_animation():
    print(f"{COLOR_CODE['RESET']}[+] {COLOR_CODE['RED']}Loading.", end='', flush=True)
    time.sleep(1)

    print(f"\r{COLOR_CODE['RESET']}[+] {COLOR_CODE['RED']}Loading..", end='', flush=True)
    time.sleep(0.8)

    print(f"\r{COLOR_CODE['RESET']}[+] {COLOR_CODE['RED']}Loading...", end='', flush=True)
    time.sleep(0.5)

    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading..", end='', flush=True)
    time.sleep(1)

    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading.", end='', flush=True)
    time.sleep(0.5)

    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading..", end='', flush=True)

    time.sleep(1)

    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading.", end='', flush=True)

    time.sleep(0.5)
    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading..", end='', flush=True)

    time.sleep(1)

    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading.", end='', flush=True)

    time.sleep(0.5)
    print(f"\r{COLOR_CODE['RESET']}", end='', flush=True)
    print(f"[+] {COLOR_CODE['RED']}Loading..", end='', flush=True)

    time.sleep(1)

    print(f"\r{COLOR_CODE['RESET']}\033[K", end='', flush=True)

    time.sleep(0.2)

    print(f"\r{COLOR_CODE['RESET']}[+] {COLOR_CODE['RED']}OPENING NOMETATOOL | V2.", end='', flush=True)
    time.sleep(2)

    print("\r", end='', flush=True)

    clear()

    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'meta.py')])


if __name__ == "__main__":
    loading_animation()
