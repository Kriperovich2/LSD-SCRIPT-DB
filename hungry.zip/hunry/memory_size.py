import os
import subprocess
import sys

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}

def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")

def convert_to_bits(input_str):
    units = {'tb': 1e12, 'gb': 1e9, 'mb': 1e6, 'kb': 1e3, 'b': 1, 'bit': 0.125}

    input_parts = input_str.split()

    if len(input_parts) == 2:
        input_value, input_unit = float(input_parts[0]), input_parts[1].lower()

        if input_unit in units:
            bytes_value = input_value * units[input_unit]
            kilobytes = bytes_value / 1024
            megabytes = kilobytes / 1024
            gigabytes = megabytes / 1024
            terabytes = gigabytes / 1024
            bits = bytes_value * 8

            print(" ")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {terabytes:.2f} TB")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {gigabytes:.2f} GB")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {megabytes:.2f} MB")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {kilobytes:.2f} KB")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {bytes_value:.2f} B")
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}     {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}= {bits:.2e} bit")

        else:
            print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}Неверная единица измерения. Пожалуйста, используйте TB, GB, MB, KB, B или bit.")
    else:
        print(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}Неверный формат ввода. Введите значение и единицу измерения через пробел.")

input_str = input(f"                   {COLOR_CODE['RED']}{COLOR_CODE['BOLD']}Введите значение и единицу измерения (например, '1 TB') >> ")
convert_to_bits(input_str)
input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}\n                   {COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}Нажмите Enter, чтобы вернуться в меню')
clear()
subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'blessed.py')])
