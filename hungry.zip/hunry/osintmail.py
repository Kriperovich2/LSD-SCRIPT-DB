import concurrent
import os
import sys
import subprocess
from concurrent.futures import ThreadPoolExecutor
import threading

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
}

def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")

def mail1(database_file1, search_value, found_flag):
    with open(database_file1, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    for line in lines:
        data = line.strip().split(';')
        if len(data) >= 8:
            date = data[0]
            last_name = data[1]
            first_name = data[2]
            middle_name = data[3]
            gender = data[4]
            birthday = data[5]
            adress = data[6]
            passport = data[7]
            email = data[8]
            if search_value in email:
                print(f'''{COLOR_CODE["RED"]}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}ID: {COLOR_CODE["RED"]}{date if date else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}last_name: {COLOR_CODE["RED"]}{last_name if last_name else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}first_name: {COLOR_CODE["RED"]}{first_name if first_name else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}middle_name: {COLOR_CODE["RED"]}{middle_name if middle_name else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}gender: {COLOR_CODE["RED"]}{gender if gender else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}birthday: {COLOR_CODE["RED"]}{birthday if birthday else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}adress: {COLOR_CODE["RED"]}{adress if adress else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}passport: {COLOR_CODE["RED"]}{passport if passport else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}email: {COLOR_CODE["RED"]}{email if email else "Не найдено"}
                {COLOR_CODE["RED"]}
                      ''')
                found_flag.set()
                input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
                clear()
                subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'meta.py')])

def mail2(database_files, search_value, found_flag):
    for database_file in database_files:
        with open(database_file, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        for line in lines:
            data = line.strip().split(';')
            if len(data) >= 5:
                user_id = data[0]
                registration_date = data[1]
                last_name = data[2]
                first_name = data[3]
                middle_name = data[4]
                birth_date = data[5]
                gender = data[6]
                phone = data[7]
                email = data[8]
                role = data[9]
                role_in_competition = data[10]
                role_in_event = data[11]
                class_num = data[12]
                class_letter = data[13]
                course = data[14]
                citizenship = data[15]
                country_of_study = data[16]
                region = data[17]
                municipal_education = data[18]
                institution_name = data[19]
                address = data[20]
                position = data[21]
                institution_type = data[22]
                public_organization = data[23]
                your_code = data[24]
                your_vector = data[25]
                your_choice = data[26]
                challenge = data[27]
                introduce_yourself = data[28]
                team_race = data[29]
                do_good = data[30]

                if search_value in email:
                    print(f'''{COLOR_CODE["RED"]}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}ID пользователя: {COLOR_CODE["RED"]}{user_id if user_id else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Дата регистрации: {COLOR_CODE["RED"]}{registration_date if registration_date else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Фамилия: {COLOR_CODE["RED"]}{last_name if last_name else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Имя: {COLOR_CODE["RED"]}{first_name if first_name else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Отчество: {COLOR_CODE["RED"]}{middle_name if middle_name else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Дата рождения: {COLOR_CODE["RED"]}{birth_date if birth_date else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Пол: {COLOR_CODE["RED"]}{gender if gender else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Телефон: {COLOR_CODE["RED"]}{phone if phone else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Электронная почта: {COLOR_CODE["RED"]}{email if email else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Роль: {COLOR_CODE["RED"]}{role if role else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Роль в конкурсе: {COLOR_CODE["RED"]}{role_in_competition if role_in_competition else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Роль в событии: {COLOR_CODE["RED"]}{role_in_event if role_in_event else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Класс: {COLOR_CODE["RED"]}{class_num if class_num else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Литера класса: {COLOR_CODE["RED"]}{class_letter if class_letter else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Курс: {COLOR_CODE["RED"]}{course if course else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Гражданство: {COLOR_CODE["RED"]}{citizenship if citizenship else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Страна обучения: {COLOR_CODE["RED"]}{country_of_study if country_of_study else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Регион: {COLOR_CODE["RED"]}{region if region else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Муниципальное образование: {COLOR_CODE["RED"]}{municipal_education if municipal_education else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Наименование учреждения: {COLOR_CODE["RED"]}{institution_name if institution_name else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Адрес: {COLOR_CODE["RED"]}{address if address else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Должность: {COLOR_CODE["RED"]}{position if position else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Тип учебного заведения: {COLOR_CODE["RED"]}{institution_type if institution_type else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Общественная организация: {COLOR_CODE["RED"]}{public_organization if public_organization else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Твой код: {COLOR_CODE["RED"]}{your_code if your_code else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Твой вектор: {COLOR_CODE["RED"]}{your_vector if your_vector else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Твой выбор: {COLOR_CODE["RED"]}{your_choice if your_choice else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Вызов: {COLOR_CODE["RED"]}{challenge if challenge else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Представь себя: {COLOR_CODE["RED"]}{introduce_yourself if introduce_yourself else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Командная гонка: {COLOR_CODE["RED"]}{team_race if team_race else "Не найдено"}
                        {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}Твори добро: {COLOR_CODE["RED"]}{do_good if do_good else "Не найдено"}
                    {COLOR_CODE["RED"]}
                        ''')
                    found_flag.set()
                    input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
                    clear()
                    subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'meta.py')])

def mail3(database_file3, search_value, found_flag):
    with open(database_file3, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    for line in lines:
        data = line.strip().split(',')
        if len(data) >= 8:
            email = data[0]
            firstname = data[1]
            lastname = data[2]
            password_hash = data[3]
            _address_city = data[4]
            _address_country_id = data[5]
            _address_street = data[6]
            _address_telephone = data[7]


            if search_value in email:
                print(f'''{COLOR_CODE["RED"]}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}email: {COLOR_CODE["RED"]}{email if email else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}firstname: {COLOR_CODE["RED"]}{firstname if firstname else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}lastname: {COLOR_CODE["RED"]}{lastname if lastname else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}password_hash: {COLOR_CODE["RED"]}{password_hash if password_hash else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}_address_city: {COLOR_CODE["RED"]}{_address_city if _address_city else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}_address_country_id: {COLOR_CODE["RED"]}{_address_country_id if _address_country_id else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}_address_street: {COLOR_CODE["RED"]}{_address_street if _address_street else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}_address_telephone: {COLOR_CODE["RED"]}{_address_telephone if _address_telephone else "Не найдено"}
                {COLOR_CODE["RED"]}
                      ''')
                found_flag.set()
                input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
                clear()
                subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'meta.py')])

if __name__ == '__main__':
    search_value = input(f'{COLOR_CODE["RED"]}                   Введите емайл >> ')
    database_file1 = 'esia.044.csv'
    database_files = 'part1.csv', 'part2.csv', 'part3.csv', 'part4.csv', 'part5.csv', 'part6.csv'
    database_file3 = 'sportua.csv'


    found_flag = threading.Event()

    with ThreadPoolExecutor(max_workers=2) as executor:
        future1 = executor.submit(mail1, database_file1, search_value, found_flag)
        future2 = executor.submit(mail2, database_files, search_value, found_flag)
        future3 = executor.submit(mail3, database_file3, search_value, found_flag)

        concurrent.futures.wait([future1, future2, future3])

    if not found_flag.is_set():
        print(f"{COLOR_CODE['RED']}                   Ничего не найдено!")
        input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
        clear()
        subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'blessed.py')])
    else:
        clear()

