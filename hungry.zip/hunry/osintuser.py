import concurrent
import os
import sys
import subprocess
from concurrent.futures import ThreadPoolExecutor
import threading

COLOR_CODE = {
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
}

def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')
        sys.stdout.write("\x1b[8;40;140t")



def user1(database_file, search_value, found_flag):
    with open(database_file, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    for line in lines:
        data = line.strip().split(',')
        if len(data) >= 5:
            id = data[0]
            phone = data[1]
            username = data[2]
            first_name = data[3]
            last_name = data[4]
            if search_value in username:
                print(f'''{COLOR_CODE["RED"]}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}ID: {COLOR_CODE["RED"]}{id if id else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}phone: {COLOR_CODE["RED"]}{phone if phone else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}username: {COLOR_CODE["RED"]}{username if username else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}first_name: {COLOR_CODE["RED"]}{first_name if first_name else "Не найдено"}
                         {COLOR_CODE["RED"]}[+]{COLOR_CODE["RESET"]}last_name: {COLOR_CODE["RED"]}{last_name if last_name else "Не найдено"}
                {COLOR_CODE["RED"]}
                      ''')
                found_flag.set()
                input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
                clear()
                subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'meta.py')])


if __name__ == '__main__':
    search_value = input(f'{COLOR_CODE["RED"]}                   Введите никнейм (Без @) >> ')
    database_file = 'eyegod_number.csv'


    found_flag = threading.Event()

    with ThreadPoolExecutor(max_workers=2) as executor:
        future1 = executor.submit(user1, database_file, search_value, found_flag)


        concurrent.futures.wait([future1])

    if not found_flag.is_set():
        print(f"{COLOR_CODE['RED']}                   Ничего не найдено!")
        input(f'{COLOR_CODE["RED"]}{COLOR_CODE["BOLD"]}                   Нажмите ENTER, чтобы выйти в меню')
        clear()
        subprocess.run(['python', os.path.join(os.path.dirname(__file__), 'blessed.py')])
    else:
        clear()
