document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();  // Остановить отправку формы по умолчанию

    const phone = document.getElementById('phone').value;
    const country = document.getElementById('country').value;
    const keepSignedIn = document.getElementById('keep-signed-in').checked;

    fetch('/submit_phone', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            phone: phone,
            country: country,
            keep_signed_in: keepSignedIn
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message) {
            alert('Phone number submitted successfully');
        } else if (data.error) {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
